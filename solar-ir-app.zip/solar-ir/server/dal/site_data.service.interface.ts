import {SiteDefinition} from "../../common/models/site-definition";
import {IDBService} from "./data.service.interface";

/*
    Data Service for adding and getting Sites
*/
export interface ISiteDataService extends IDBService {

    addSite(site: SiteDefinition): Promise<number>;

    getSiteById(id: number): Promise<SiteDefinition | undefined>;

    getSiteByName(name: string): Promise<SiteDefinition | undefined>;

    getSites(): Promise<SiteDefinition[] | undefined>;
}