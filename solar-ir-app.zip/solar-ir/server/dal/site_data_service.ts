import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "../managers/logger_manager";
import {SiteDefinition} from "../../common/models/site-definition";
import {ISiteDataService} from "./site_data.service.interface";
import {SiteRecord} from "./records/site_record";
import {DBHelper} from "../helpers/db-helper";

const Datastore = require('nedb');

@injectable()
export class SiteDataService implements ISiteDataService {

    private sitesDb = new Datastore({ filename: process.env.dbPersistPath + '/sites.db', autoload: true });

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    getSiteInternal(params: {id?: number, name?: string}): Promise<SiteDefinition | undefined> {
        return new Promise((resolve, reject) => {

            this.sitesDb.findOne(params, function (err, rec) {
                if (err) reject(err);
                if (rec) {
                    console.log(`Found Record: ${rec._id}`);
                }
                resolve(rec ? {
                    id: rec.id,
                    name: rec.name,
                    location: rec.location,
                    pipeline: {
                        id: -1
                    }} : undefined);
            });
        });
    }

    getSiteById(id: number): Promise<SiteDefinition | undefined> {
        return this.getSiteInternal({id});
    }

    getSiteByName(name: string): Promise<SiteDefinition | undefined> {
        return this.getSiteInternal({name});
    }

    getSites(): Promise<SiteDefinition[] | undefined> {
        return new Promise((resolve, reject) => {
            this.sitesDb.find({}, function (err, recs: SiteRecord[]) {
                if (err) reject(err);
                console.log(`Found Records: ${JSON.stringify((recs || []).map(r => r._id))}`);
                resolve((recs || []).map(rec => {
                    return {
                        id: rec.id,
                        name: rec.name,
                        location: rec.location,
                        pipeline: {
                            id: -1
                        }}
                }));
            });
        });
    }

    addSite(site: SiteDefinition): Promise<number> {
        return new Promise((resolve, reject) => {

            this.sitesDb.insert(DBHelper.addWithTimestamps(site), function (err, savedRec) {
                console.log('Saved Site Record: ', savedRec._id);
                resolve(savedRec.id);
            });
        });
    }

    saveData(data: SiteDefinition, args?: any): Promise<any> {
        return this.addSite(data);
    }

}