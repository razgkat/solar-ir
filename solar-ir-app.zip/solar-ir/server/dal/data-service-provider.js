"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const inversify_types_1 = require("../inversify.types");
const container_1 = require("../container");
const db_service_type_1 = require("../../common/enums/db-service-type");
let DataServiceProvider = class DataServiceProvider {
    constructor(logger) {
        this.logger = logger;
    }
    /*
        Fetch DB Service by Type and Key (Can be Optional)
    */
    getDbService(dbServiceType, dbIdentifier) {
        switch (dbServiceType) {
            case db_service_type_1.DbServiceType.NeDB:
                switch (dbIdentifier) {
                    case "results":
                        return container_1.container.get(inversify_types_1.TYPES.ExecutionResultDataService);
                    case "executions":
                        return container_1.container.get(inversify_types_1.TYPES.ExecutionDataService);
                    case "sites":
                        return container_1.container.get(inversify_types_1.TYPES.SiteDataService);
                    case "pipelines":
                        return container_1.container.get(inversify_types_1.TYPES.PipelineDataService);
                }
                throw Error(`Could not find db matches the identifier of ${dbIdentifier}`);
            default:
                throw Error(`Got ${dbServiceType}, invalid db service type provided`);
        }
    }
};
DataServiceProvider = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.inject(inversify_types_1.TYPES.Logger)),
    __metadata("design:paramtypes", [Object])
], DataServiceProvider);
exports.DataServiceProvider = DataServiceProvider;
//# sourceMappingURL=data-service-provider.js.map