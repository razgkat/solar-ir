import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "../managers/logger_manager";
import {IDBService} from "./data.service.interface";
import {container} from "../container";
import {IExecutionResultDataService} from "./execution-result-data.service.interface";
import {ILocalFileWriter} from "../helpers/storage-utils";
import {DbServiceType} from "../../common/enums/db-service-type";


export interface IDBServiceProvider {
    getDbService(dbServiceType: DbServiceType, dbIdentifier?: string): IDBService;
}

@injectable()
export class DataServiceProvider implements  IDBServiceProvider {

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    /*
        Fetch DB Service by Type and Key (Can be Optional)
    */
    getDbService(dbServiceType: DbServiceType, dbIdentifier?: string): IDBService {
        switch(dbServiceType)
        {
            case DbServiceType.NeDB:
                switch (dbIdentifier)
                {
                    case "results":
                        return container.get<IExecutionResultDataService>(TYPES.ExecutionResultDataService);
                    case "executions":
                        return container.get<IExecutionResultDataService>(TYPES.ExecutionDataService);
                    case "sites":
                        return container.get<IExecutionResultDataService>(TYPES.SiteDataService);
                    case "pipelines":
                        return container.get<IExecutionResultDataService>(TYPES.PipelineDataService);
                }
                throw Error(`Could not find db matches the identifier of ${dbIdentifier}`);

            default:
                throw Error(`Got ${dbServiceType}, invalid db service type provided`);
        }
    }
}