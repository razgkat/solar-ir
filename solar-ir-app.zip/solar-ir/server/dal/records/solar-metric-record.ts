import {DbRecord} from "./db_record";
import {SolarMetric} from "../../../common/models/solar-metric";

/*
    Solar Metric Record (NrelSolarFlatTaskTransform Task Result) saved to DB
 */
export type SolarMetricRecord = SolarMetric & DbRecord;