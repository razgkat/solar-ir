import * as moment from "moment";
import {Moment} from "moment";

/*
    General DB Record containing DB internal ID and Times, those added to any persisted record
 */
export interface DbRecord {
    _id?: string;
    updateTime: string;
    createTime: string;
    updateTimeUtc: number;
    createTimeUtc: number;
}

export namespace DBUtil {

    export const updateWithTimestamps = (r: DbRecord, time?: Moment): void => {
        const t = time || moment();

        r.updateTime = r.createTime = t.toISOString(true);
        r.updateTimeUtc = r.createTimeUtc = t.unix();
    }
}