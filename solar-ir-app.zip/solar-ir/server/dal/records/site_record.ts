import {SiteDefinition, SiteLocation} from "../../../common/models/site-definition";
import {DbRecord} from "./db_record";

/*
    Site Record saved to DB
 */
export type SiteRecord = SiteDefinition & DbRecord;
