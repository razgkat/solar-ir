import {DbRecord} from "./db_record";
import {PipelineDefinition} from "../../../common/models/pipeline-definition";

/*
    Pipeline Record saved to DB
 */
export type PipelineRecord = PipelineDefinition & DbRecord;
