"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment");
var DBUtil;
(function (DBUtil) {
    DBUtil.updateWithTimestamps = (r, time) => {
        const t = time || moment();
        r.updateTime = r.createTime = t.toISOString(true);
        r.updateTimeUtc = r.createTimeUtc = t.unix();
    };
})(DBUtil = exports.DBUtil || (exports.DBUtil = {}));
//# sourceMappingURL=db_record.js.map