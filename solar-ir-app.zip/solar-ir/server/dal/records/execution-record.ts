import {DbRecord} from "./db_record";
import {ExecutionDefinition} from "../../../common/models/execution-definition";
import {ExecutionDataResult} from "../../../common/models/execution-data-result";

/*
    Execution Record saved to DB
 */
export type ExecutionRecord = ExecutionDefinition & DbRecord;

export type ExectionDataResultRecord = ExecutionDataResult & DbRecord;