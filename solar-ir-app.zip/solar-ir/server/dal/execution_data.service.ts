import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "../managers/logger_manager";
import {ExecutionRecord} from "./records/execution-record";
import {ExecutionDefinition} from "../../common/models/execution-definition";
import {ExecutionStatus} from "../../common/enums/execution-status";
import moment = require("moment");
import {IExecutionDataService} from "./execution_data.service.interface";
import {DBHelper} from "../helpers/db-helper";

const Datastore = require('nedb');

@injectable()
export class ExecutionDataService implements IExecutionDataService {

    private executionsDb = new Datastore({ filename: process.env.dbPersistPath + '/executions.db', autoload: true });

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }


    getExecution(key: string): Promise<ExecutionDefinition | undefined> {

        return new Promise((resolve, reject) => {

            this.executionsDb.findOne({key}, function (err, rec: ExecutionRecord) {
                if (err) reject(err);
                if (rec) { console.log(`Found Record: ${rec._id}`); }
                resolve(DBHelper.removeinternalId(rec));
            });
        })
    }

    getExecutions(filter: {siteId?: number, status?: ExecutionStatus}): Promise<ExecutionDefinition[]> {

        return new Promise((resolve, reject) => {

            this.executionsDb.find(filter || {}).exec((err, recs: ExecutionRecord[]) => {
                if (err) reject(err);
                if (recs) { console.log(`Found Total ${recs.length} Records`); }
                resolve(recs.map(r => DBHelper.removeinternalId(r)));
            });
        })
    }

    getLastExecution(siteId: number): Promise<ExecutionDefinition | undefined> {
        return new Promise((resolve, reject) => {

            this.executionsDb.find({ siteId: siteId }).sort({createTimeUtc: -1}).exec((err, recs: ExecutionRecord[]) => {
                if (err) reject(err);
                if (recs) {
                    console.log(`getLastExecution, Found Execution ${recs.length} Records`);
                }
                resolve(recs.length > 0 ? DBHelper.removeinternalId(recs[0]) : undefined);
            });
        })
    }

    addExecution(executionDef: ExecutionDefinition): Promise<number> {
        return new Promise((resolve, reject) => {

            this.executionsDb.insert(DBHelper.addWithTimestamps(executionDef), function (err, savedRec) {
                console.log('Saved Pipeline Record: ', savedRec._id);
                resolve(savedRec.id);
            });
        });
    }

    updateExecutionStatus(key: string, newStatus: ExecutionStatus):Promise<boolean> {

        return new Promise((resolve, reject) => {

            const nowTs = moment();

            this.executionsDb.update({ key: key },
                { $set: { status: newStatus, updateTime: nowTs.toISOString(true), updateTimeUtc: nowTs.unix() } },
                {}, function (err, updatedRecCnt) {
                    console.log(`Updated ${updatedRecCnt} Execution Record`);
                    if (err) reject(false)
                    resolve(true);
                });
        });
    }

    saveData(data: ExecutionDefinition, args?: any): Promise<any> {
        return this.addExecution(data);
    }

}