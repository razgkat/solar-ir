import {ExecutionDataResult} from "../../common/models/execution-data-result";
import {IDBService} from "./data.service.interface";

/*
    Data Service for getting and saving Pipeline Results
*/
export interface IExecutionResultDataService extends IDBService {

    getResults(filter?: {executionKey?: string, siteName?: string }): Promise<ExecutionDataResult[] | undefined>;

    saveResult<T extends ExecutionDataResult>(result: T): Promise<void>;
}