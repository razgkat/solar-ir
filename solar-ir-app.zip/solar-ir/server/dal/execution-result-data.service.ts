import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "../managers/logger_manager";
import {DBHelper} from "../helpers/db-helper";
import {IExecutionResultDataService} from "./execution-result-data.service.interface";
import {ExecutionDataResult} from "../../common/models/execution-data-result";
import {ExectionDataResultRecord} from "./records/execution-record";
import {ExecutionDefinition} from "../../common/models/execution-definition";

const Datastore = require('nedb');

@injectable()
export class ExecutionResultDataService implements IExecutionResultDataService {

    private resultsDb = new Datastore({ filename: process.env.dbPersistPath + '/results.db', autoload: true });

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    getResults(filter?: {executionKey?: string }): Promise<ExecutionDataResult[] | undefined> {

        return new Promise((resolve, reject) => {

            this.resultsDb.find(filter || {}).exec((err, recs: ExectionDataResultRecord[]) => {
                if (err) reject(err);
                if (recs) { console.log(`Found Total ${recs.length} Records`); }
                resolve(recs.map(r => DBHelper.removeinternalId(r)));
            });
        })
    }

    saveResult(result: ExecutionDataResult): Promise<void> {
        return new Promise((resolve, reject) => {

            this.resultsDb.insert(DBHelper.addWithTimestamps(result), function (err, savedRec) {
                console.log('Saved Execution Result Record: ', savedRec._id);
                resolve(savedRec.id);
            });
        });
    }

    saveData(data: ExecutionDataResult, args?: any): Promise<any> {
        return this.saveResult(data);
    }
}