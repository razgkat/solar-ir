import {ExecutionDefinition} from "../../common/models/execution-definition";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {IDBService} from "./data.service.interface";

/*
    Data Service for adding, getting and running executions
*/
export interface IExecutionDataService extends IDBService {

    getExecution(key: string): Promise<ExecutionDefinition | undefined>;

    getLastExecution(siteId: number): Promise<ExecutionDefinition | undefined>;

    getExecutions(filter?: {siteId?: number, status?: ExecutionStatus}): Promise<ExecutionDefinition[]>;

    addExecution(executionDef: ExecutionDefinition): Promise<number>;

    updateExecutionStatus(key: string, newStatus: ExecutionStatus):Promise<boolean>;
}