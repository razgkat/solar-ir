import {PipelineDefinition} from "../../common/models/pipeline-definition";
import {IDBService} from "./data.service.interface";

/*
    Data Service for adding and getting Pipelines
*/
export interface IPipelineDataService extends IDBService {

    addPipeline(pipeLine: PipelineDefinition): Promise<number>;

    getPipeline(id: number): Promise<PipelineDefinition | undefined>;

    getPipelines(): Promise<PipelineDefinition[] | undefined>;
}