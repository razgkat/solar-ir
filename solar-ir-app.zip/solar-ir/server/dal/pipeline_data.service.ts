import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "../managers/logger_manager";
import {IPipelineDataService} from "./pipeline_data.service.interface";
import {PipelineDefinition} from "../../common/models/pipeline-definition";
import {PipelineRecord} from "./records/pipeline-record";
import {DBHelper} from "../helpers/db-helper";
import {ExecutionDataResult} from "../../common/models/execution-data-result";

const Datastore = require('nedb');

@injectable()
export class PipelineDataService implements IPipelineDataService {

    private pipelinesDb = new Datastore({ filename: process.env.dbPersistPath + '/pipelines.db', autoload: true });

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    addPipeline(pipeline: PipelineDefinition): Promise<number> {
        return new Promise((resolve, reject) => {

           this.pipelinesDb.insert(DBHelper.addWithTimestamps(pipeline), function (err, savedRec) {
                console.log('Saved Pipeline Record: ', savedRec._id);
                resolve(savedRec.id);
            });
        });
    }

    getPipeline(id: number): Promise<PipelineDefinition | undefined> {

        return new Promise((resolve, reject) => {
            this.pipelinesDb.findOne({id}, function (err, rec: PipelineRecord) {
                if (err) reject(err);
                if (rec) {  console.log(`Found Pipeline Record: ${rec._id}`); }
                resolve(rec ? {
                    id: rec.id,
                    name: rec.name,
                    tasks: rec.tasks} : undefined);
            });
        })
    }

    getPipelines(): Promise<PipelineDefinition[] | undefined> {
        return new Promise((resolve, reject) => {
            this.pipelinesDb.find({}, function (err, recs: PipelineRecord[]) {
                if (err) reject(err);
                console.log(`Found Pipeline Records: ${JSON.stringify((recs || []).map(r => r._id))}`);
                resolve((recs || []).map(rec => {
                    return {
                        id: rec.id,
                        name: rec.name,
                        tasks: rec.tasks
                    }
                }));
            });
        });
    }

    saveData(data: PipelineDefinition, args?: any): Promise<any> {
        return this.addPipeline(data);
    }

}