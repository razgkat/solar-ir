"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const inversify_types_1 = require("../inversify.types");
const db_helper_1 = require("../helpers/db-helper");
const Datastore = require('nedb');
let SiteDataService = class SiteDataService {
    constructor(logger) {
        this.logger = logger;
        this.sitesDb = new Datastore({ filename: process.env.dbPersistPath + '/sites.db', autoload: true });
    }
    getSiteInternal(params) {
        return new Promise((resolve, reject) => {
            this.sitesDb.findOne(params, function (err, rec) {
                if (err)
                    reject(err);
                if (rec) {
                    console.log(`Found Record: ${rec._id}`);
                }
                resolve(rec ? {
                    id: rec.id,
                    name: rec.name,
                    location: rec.location,
                    pipeline: {
                        id: -1
                    }
                } : undefined);
            });
        });
    }
    getSiteById(id) {
        return this.getSiteInternal({ id });
    }
    getSiteByName(name) {
        return this.getSiteInternal({ name });
    }
    getSites() {
        return new Promise((resolve, reject) => {
            this.sitesDb.find({}, function (err, recs) {
                if (err)
                    reject(err);
                console.log(`Found Records: ${JSON.stringify((recs || []).map(r => r._id))}`);
                resolve((recs || []).map(rec => {
                    return {
                        id: rec.id,
                        name: rec.name,
                        location: rec.location,
                        pipeline: {
                            id: -1
                        }
                    };
                }));
            });
        });
    }
    addSite(site) {
        return new Promise((resolve, reject) => {
            this.sitesDb.insert(db_helper_1.DBHelper.addWithTimestamps(site), function (err, savedRec) {
                console.log('Saved Site Record: ', savedRec._id);
                resolve(savedRec.id);
            });
        });
    }
    saveData(data, args) {
        return this.addSite(data);
    }
};
SiteDataService = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.inject(inversify_types_1.TYPES.Logger)),
    __metadata("design:paramtypes", [Object])
], SiteDataService);
exports.SiteDataService = SiteDataService;
//# sourceMappingURL=site_data_service.js.map