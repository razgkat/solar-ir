import {ExecutionDataResult} from "../../common/models/execution-data-result";
import {IExecutionContext} from "../execution/pipeline-execution-context";

/*
    Represents a Generic DB Service for saving data
 */
export interface IDBService {
    saveData(data: any, args?: any): Promise<any>;
}