"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const inversify_types_1 = require("../inversify.types");
const moment = require("moment");
const db_helper_1 = require("../helpers/db-helper");
const Datastore = require('nedb');
let ExecutionDataService = class ExecutionDataService {
    constructor(logger) {
        this.logger = logger;
        this.executionsDb = new Datastore({ filename: process.env.dbPersistPath + '/executions.db', autoload: true });
    }
    getExecution(key) {
        return new Promise((resolve, reject) => {
            this.executionsDb.findOne({ key }, function (err, rec) {
                if (err)
                    reject(err);
                if (rec) {
                    console.log(`Found Record: ${rec._id}`);
                }
                resolve(db_helper_1.DBHelper.removeinternalId(rec));
            });
        });
    }
    getExecutions(filter) {
        return new Promise((resolve, reject) => {
            this.executionsDb.find(filter || {}).exec((err, recs) => {
                if (err)
                    reject(err);
                if (recs) {
                    console.log(`Found Total ${recs.length} Records`);
                }
                resolve(recs.map(r => db_helper_1.DBHelper.removeinternalId(r)));
            });
        });
    }
    getLastExecution(siteId) {
        return new Promise((resolve, reject) => {
            this.executionsDb.find({ siteId: siteId }).sort({ createTimeUtc: -1 }).exec((err, recs) => {
                if (err)
                    reject(err);
                if (recs) {
                    console.log(`getLastExecution, Found Execution ${recs.length} Records`);
                }
                resolve(recs.length > 0 ? db_helper_1.DBHelper.removeinternalId(recs[0]) : undefined);
            });
        });
    }
    addExecution(executionDef) {
        return new Promise((resolve, reject) => {
            this.executionsDb.insert(db_helper_1.DBHelper.addWithTimestamps(executionDef), function (err, savedRec) {
                console.log('Saved Pipeline Record: ', savedRec._id);
                resolve(savedRec.id);
            });
        });
    }
    updateExecutionStatus(key, newStatus) {
        return new Promise((resolve, reject) => {
            const nowTs = moment();
            this.executionsDb.update({ key: key }, { $set: { status: newStatus, updateTime: nowTs.toISOString(true), updateTimeUtc: nowTs.unix() } }, {}, function (err, updatedRecCnt) {
                console.log(`Updated ${updatedRecCnt} Execution Record`);
                if (err)
                    reject(false);
                resolve(true);
            });
        });
    }
    saveData(data, args) {
        return this.addExecution(data);
    }
};
ExecutionDataService = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.inject(inversify_types_1.TYPES.Logger)),
    __metadata("design:paramtypes", [Object])
], ExecutionDataService);
exports.ExecutionDataService = ExecutionDataService;
//# sourceMappingURL=execution_data.service.js.map