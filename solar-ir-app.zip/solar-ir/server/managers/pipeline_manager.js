"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const inversify_types_1 = require("../inversify.types");
const request_status_1 = require("../../common/enums/request-status");
const container_1 = require("../container");
let PipelineManager = class PipelineManager {
    constructor(logger) {
        this.logger = logger;
    }
    addPipeline(addPipelineRequest) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.info(`addPipeline, got pipeline definition ${JSON.stringify(addPipelineRequest.pipeline.name)}`);
            const existPpl = yield this.pipelineDataService.getPipeline(addPipelineRequest.pipeline.id);
            if (existPpl) {
                throw Error("Pipeline with the same ID already exists !");
            }
            return this.pipelineDataService.addPipeline(addPipelineRequest.pipeline).then((id) => {
                return {
                    id: id,
                    status: request_status_1.RequestStatus.Success,
                    message: "Pipeline added Successfully"
                };
            });
        });
    }
    getPipeline(id) {
        return __awaiter(this, void 0, void 0, function* () {
            let retPipeline = yield this.pipelineDataService.getPipeline(id);
            return Promise.resolve({
                pipeline: retPipeline || {},
                status: retPipeline ? request_status_1.RequestStatus.Success : request_status_1.RequestStatus.NotFound,
            });
        });
    }
    getPipelines() {
        return __awaiter(this, void 0, void 0, function* () {
            const pipelines = yield this.pipelineDataService.getPipelines();
            return Promise.resolve({
                pipelines: pipelines || [],
                status: pipelines ? request_status_1.RequestStatus.Success : request_status_1.RequestStatus.NotFound
            });
        });
    }
};
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.PipelineDataService),
    __metadata("design:type", Object)
], PipelineManager.prototype, "pipelineDataService", void 0);
PipelineManager = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.inject(inversify_types_1.TYPES.Logger)),
    __metadata("design:paramtypes", [Object])
], PipelineManager);
exports.PipelineManager = PipelineManager;
//# sourceMappingURL=pipeline_manager.js.map