import * as moment from "moment";
import * as winston from "winston";
import * as path from "path";
import {TransformableInfo} from "logform";

export type LogLevel = 'error' | 'warn' | 'info' | 'debug';

/*
        Logger Manager used to provide API for logging
 */

export class LoggerManager implements ILogger {
    private static DEFAULT_OPTS = {
        console: {
            enabled: true,
            level: <LogLevel>"info",
            timeFormat: "DD-MM-YYYY HH:mm:ss.SSS",
            colored: true,
        },
        file: {
            enabled: true,
            level: <LogLevel>"info" ,
            filename: (process.env.name || "winston") + ".log",
            timeFormat: "DD-MM-YYYY HH:mm:ss.SSS"
        },
        errorFile: {
            enabled: true,
            timeFormat: "DD-MM-YYYY HH:mm:ss.SSS"
        }
    };

    private logger: winston.Logger;

    constructor(opts: {
        console?: {
            enabled?: boolean;
            level?: LogLevel;
            timeFormat?: string;
            colored?: boolean;
        }
        file?: {
            enabled?: boolean;
            level?: LogLevel;
            filename?: string;
            timeFormat?: string;
        },
        errorFile?: {
            enabled?: boolean;
            filename?: string;
            timeFormat?: string;
        }
    } = {}) {

        opts = {
            console: {...LoggerManager.DEFAULT_OPTS.console, ...opts.console},
            file: {...LoggerManager.DEFAULT_OPTS.file, ...opts.file},
            errorFile: {...LoggerManager.DEFAULT_OPTS.errorFile, ...opts.errorFile}
        };

        if (!opts.errorFile.filename) {
            const ext = path.extname(opts.file.filename);
            let file = path.basename(opts.file.filename, ext);
            const dir = path.dirname(opts.file.filename);

            opts.errorFile.filename = path.join(dir, file + "-error" + ext);
        }

        this.logger = winston.createLogger({exitOnError: false});

        if (opts.console.enabled) {
            const colorize = opts.console.colored ? winston.format.colorize({all: true}) : undefined;
            this.logger.add(new winston.transports.Console({
                level: opts.console.level,
                format: winston.format.combine(
                    winston.format.simple(),
                    winston.format.printf(({level, message, stack}: TransformableInfo & { stack: string }) => {
                        stack = stack ? '\n' + stack : '';
                        return `${moment().format(opts.console.timeFormat)}|${level.toUpperCase()}| ${message}${stack}`;
                    }),
                    colorize
                ),
                handleExceptions: true
            }));
        }

        if (opts.file.enabled) this.logger.add(new winston.transports.File({
            filename: opts.file.filename,
            level: opts.file.level,
            maxsize: 20000000, //20MB
            maxFiles: 10,
            tailable: true,
            format: winston.format.combine(
                winston.format.simple(),
                winston.format.printf(({level, message}) => {
                    return `${moment().format(opts.file.timeFormat)}|${level.toUpperCase()}| ${message}`;
                })
            )
        }));

        if (opts.errorFile.enabled) this.logger.add(new winston.transports.File({
            filename: opts.errorFile.filename,
            level: 'error',
            maxsize: 20000000, //20MB
            maxFiles: 10,
            tailable: true,
            format: winston.format.combine(
                winston.format.simple(),
                winston.format.printf(({level, message}) => {
                    return `${moment().format(opts.errorFile.timeFormat)}|${level.toUpperCase()}| ${message}`;
                })
            ),
            handleExceptions: true
        }));
    }

    debug(message: string, data ?: any): void {
        this.logger.debug(message, data);
    }

    error(message: string, error ?: any): void {
        // if (error && error.stack
        // )
        //     error = error.stack;
        if (error && message) message += "\n";
        this.logger.error(message, error);
    }

    info(message: string, data ?: any): void {
        this.logger.info(message, data);
    }

    warn(message: string, data ?: any): void {
        this.logger.warn(message, data);
    }

    log(level: LogLevel, message: string, data ?: any): void {
        this.logger.log(level, message, data);
    }
}


export interface ILogger {
    debug(message: string, data?: any): void;

    error(message: string, error?: any): void;

    info(message: string, data?: any): void;

    warn(message: string, data?: any): void;

    log(level: LogLevel, message: string, data?: any): void;
}
