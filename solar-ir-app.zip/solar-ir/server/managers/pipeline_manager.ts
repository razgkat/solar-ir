import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "./logger_manager";
import {GetSiteResponse, GetSitesResponse} from "../../common/models/site-request-response";
import {RequestStatus} from "../../common/enums/request-status";
import {SiteDefinition} from "../../common/models/site-definition";
import {IPipelineManager} from "./pipeline_manager.interface";
import {
    AddPipelineRequest,
    AddPipelineResponse,
    GetPipelineResponse, GetPipelinesResponse
} from "../../common/models/pipeline-request-response";
import {lazyInject} from "../container";
import {IPipelineDataService} from "../dal/pipeline_data.service.interface";
import {PipelineDefinition} from "../../common/models/pipeline-definition";

@injectable()
export class PipelineManager implements IPipelineManager {

    @lazyInject(TYPES.PipelineDataService) private readonly pipelineDataService: IPipelineDataService;

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    public async addPipeline(addPipelineRequest: AddPipelineRequest): Promise<AddPipelineResponse> {

        this.logger.info(`addPipeline, got pipeline definition ${JSON.stringify(addPipelineRequest.pipeline.name)}`)

        const existPpl =  await this.pipelineDataService.getPipeline(addPipelineRequest.pipeline.id);

        if (existPpl) {
            throw Error("Pipeline with the same ID already exists !");
        }
        return this.pipelineDataService.addPipeline(addPipelineRequest.pipeline).then((id: number) => {
            return {
                id: id,
                status: RequestStatus.Success,
                message: "Pipeline added Successfully"
            };
        });
    }

    public async getPipeline(id: number): Promise<GetPipelineResponse> {

        let retPipeline: PipelineDefinition = await this.pipelineDataService.getPipeline(id);

        return Promise.resolve({
            pipeline: retPipeline || <PipelineDefinition>{},
            status: retPipeline ? RequestStatus.Success : RequestStatus.NotFound,
        })
    }

    public async getPipelines(): Promise<GetPipelinesResponse> {

        const pipelines: PipelineDefinition[] = await this.pipelineDataService.getPipelines();

        return Promise.resolve({
            pipelines: pipelines || [],
            status: pipelines ? RequestStatus.Success : RequestStatus.NotFound
        })
    }

}