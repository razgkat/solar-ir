"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment");
const winston = require("winston");
const path = require("path");
/*
        Logger Manager used to provide API for logging
 */
class LoggerManager {
    constructor(opts = {}) {
        opts = {
            console: Object.assign({}, LoggerManager.DEFAULT_OPTS.console, opts.console),
            file: Object.assign({}, LoggerManager.DEFAULT_OPTS.file, opts.file),
            errorFile: Object.assign({}, LoggerManager.DEFAULT_OPTS.errorFile, opts.errorFile)
        };
        if (!opts.errorFile.filename) {
            const ext = path.extname(opts.file.filename);
            let file = path.basename(opts.file.filename, ext);
            const dir = path.dirname(opts.file.filename);
            opts.errorFile.filename = path.join(dir, file + "-error" + ext);
        }
        this.logger = winston.createLogger({ exitOnError: false });
        if (opts.console.enabled) {
            const colorize = opts.console.colored ? winston.format.colorize({ all: true }) : undefined;
            this.logger.add(new winston.transports.Console({
                level: opts.console.level,
                format: winston.format.combine(winston.format.simple(), winston.format.printf(({ level, message, stack }) => {
                    stack = stack ? '\n' + stack : '';
                    return `${moment().format(opts.console.timeFormat)}|${level.toUpperCase()}| ${message}${stack}`;
                }), colorize),
                handleExceptions: true
            }));
        }
        if (opts.file.enabled)
            this.logger.add(new winston.transports.File({
                filename: opts.file.filename,
                level: opts.file.level,
                maxsize: 20000000,
                maxFiles: 10,
                tailable: true,
                format: winston.format.combine(winston.format.simple(), winston.format.printf(({ level, message }) => {
                    return `${moment().format(opts.file.timeFormat)}|${level.toUpperCase()}| ${message}`;
                }))
            }));
        if (opts.errorFile.enabled)
            this.logger.add(new winston.transports.File({
                filename: opts.errorFile.filename,
                level: 'error',
                maxsize: 20000000,
                maxFiles: 10,
                tailable: true,
                format: winston.format.combine(winston.format.simple(), winston.format.printf(({ level, message }) => {
                    return `${moment().format(opts.errorFile.timeFormat)}|${level.toUpperCase()}| ${message}`;
                })),
                handleExceptions: true
            }));
    }
    debug(message, data) {
        this.logger.debug(message, data);
    }
    error(message, error) {
        // if (error && error.stack
        // )
        //     error = error.stack;
        if (error && message)
            message += "\n";
        this.logger.error(message, error);
    }
    info(message, data) {
        this.logger.info(message, data);
    }
    warn(message, data) {
        this.logger.warn(message, data);
    }
    log(level, message, data) {
        this.logger.log(level, message, data);
    }
}
LoggerManager.DEFAULT_OPTS = {
    console: {
        enabled: true,
        level: "info",
        timeFormat: "DD-MM-YYYY HH:mm:ss.SSS",
        colored: true,
    },
    file: {
        enabled: true,
        level: "info",
        filename: (process.env.name || "winston") + ".log",
        timeFormat: "DD-MM-YYYY HH:mm:ss.SSS"
    },
    errorFile: {
        enabled: true,
        timeFormat: "DD-MM-YYYY HH:mm:ss.SSS"
    }
};
exports.LoggerManager = LoggerManager;
//# sourceMappingURL=logger_manager.js.map