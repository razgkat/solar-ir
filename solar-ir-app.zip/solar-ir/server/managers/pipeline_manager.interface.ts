import {
    AddPipelineRequest,
    AddPipelineResponse, GetPipelineResponse,
    GetPipelinesResponse
} from "../../common/models/pipeline-request-response";

/*
        This Manager provides API for accessing and manipulating all the pipelines in the system
        Pipelines are basically chained tasks, linked together and run sequentially (Extract, Transform and Load)

        There are several functions supported:

        1. addPipeline - Adding new Pipeline
        2. getPipeline - Returns Pipeline associated with specific ID
        3. getPipelines - Get all available pipelines
 */

export interface IPipelineManager {

    addPipeline(addPipelineRequest: AddPipelineRequest): Promise<AddPipelineResponse>;

    getPipeline(id: number): Promise<GetPipelineResponse>;

    getPipelines(): Promise<GetPipelinesResponse>
}

