import {ISiteManager} from "./site_manager.interface";
import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "./logger_manager";
import {
    AddSiteRequest,
    AddSiteResponse,
    ExecuteSiteRequest, ExecuteSiteResponse,
    GetSiteResponse,
    GetSitesResponse
} from "../../common/models/site-request-response";
import {RequestStatus} from "../../common/enums/request-status";
import {lazyInject} from "../container";
import {ISiteDataService} from "../dal/site_data.service.interface";
import {SiteDefinition} from "../../common/models/site-definition";
import {IExecutionManager} from "./execution_manager.interface";
import {ExecutionDefinition} from "../../common/models/execution-definition";

@injectable()
export class SiteManager implements ISiteManager {

    @lazyInject(TYPES.SiteDataService) private readonly siteDataService: ISiteDataService;

    @lazyInject(TYPES.ExecutionManager) private readonly executionManager: IExecutionManager;

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    public async addSite(addSiteRequest: AddSiteRequest): Promise<AddSiteResponse> {

        this.logger.info(`addSite, got site definition ${JSON.stringify(addSiteRequest.site.name)}`)

        const existingSite =  await this.siteDataService.getSiteById(addSiteRequest.site.id);

        if (existingSite) {
            throw Error("Site with that ID already exists !");
        }
        return this.siteDataService.addSite(addSiteRequest.site).then((siteId: number) => {
            return {
                id: siteId,
                status: RequestStatus.Success,
                message: "Site Added Successfully"
            };
        });
    }

    public async getSite(idOrName: string | number): Promise<GetSiteResponse> {

        let foundSite: SiteDefinition = undefined;

        const isNumber = (s: any): s is number => {
            return !isNaN(s);
        }

        if (isNumber(idOrName)) {
            foundSite = await this.siteDataService.getSiteById(Number(idOrName));
        } else {
            foundSite = await this.siteDataService.getSiteByName(idOrName);
        }
        return Promise.resolve({
            site: foundSite || <SiteDefinition>{},
            status: foundSite ? RequestStatus.Success : RequestStatus.NotFound
        })
    }

    public async getSites(): Promise<GetSitesResponse> {

        const foundSites: SiteDefinition[] = await this.siteDataService.getSites();

        return Promise.resolve({
            sites: foundSites || [],
            status: foundSites ? RequestStatus.Success : RequestStatus.NotFound
        })
    }

    public async executeSite(executeRequest: ExecuteSiteRequest): Promise<ExecuteSiteResponse> {
        return this.executionManager.executeSite(executeRequest.siteId, executeRequest.pipelineId);
    }



}