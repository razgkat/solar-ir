import {
    AddSiteRequest,
    AddSiteResponse,
    ExecuteSiteRequest,
    ExecuteSiteResponse,
    GetSiteResponse,
    GetSitesResponse
} from "../../common/models/site-request-response";

/*
        This Manager provides API for accessing and manipulating all the sites in the system
        There are several functions supported:

        1. addSite - Adding new Site
        2. getSites - Returns list of sites existing in the system
        3. getSite - Get specific site by name or ID
        4. executeSite - Execute site with a given Pipeline ID
 */

export interface ISiteManager {

    addSite(addSiteRequest: AddSiteRequest): Promise<AddSiteResponse>;

    getSites(): Promise<GetSitesResponse>

    getSite(idOrName: string | number): Promise<GetSiteResponse>

    executeSite(executeRequest: ExecuteSiteRequest): Promise<ExecuteSiteResponse>;
}

