import {SiteDefinition} from "../../common/models/site-definition";
import {ExecuteSiteResponse} from "../../common/models/site-request-response";
import {GetExecutionResultResponse, GetExecutionsResponse} from "../../common/models/execution-request-response";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {RequestStatus} from "../../common/enums/request-status";

/*
        Execution Manager handles all the execution flow of specific paired site with a pipeline.
        In order to run execution, both Site ID and Pipeline ID shall be provided.

        There few functionalities supported:
        1. executeSite - Execute specific Site with a give Pipeline ID
        2. getExecutions - Return all registered executions, you may filter by site/execution key
           and/or final status.
        3. getExecutionResult - get specific Execution Result Data, this includes the data which
           transformed and loaded to destination defined in the "load task" of the pipeline.

        4. runExecutionBusy - This API is for debugging purposes allowing triggering specific Execution
           by passing over the Background Worker.
 */

export interface IExecutionManager
{
    executeSite(siteId: number, pipelineId?: number): Promise<ExecuteSiteResponse>;

    getExecutions(filter?: {siteId?: number, key?: string, status?: ExecutionStatus}):Promise<GetExecutionsResponse>;

    getExecutionResult(filter?: {executionKey: string}): Promise<GetExecutionResultResponse>;

    runExecutionBusy(key: string): Promise<{status: RequestStatus, message?: string}>;
}