import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "./logger_manager";
import {ExecuteSiteResponse} from "../../common/models/site-request-response";
import {RequestStatus} from "../../common/enums/request-status";
import {SiteDefinition} from "../../common/models/site-definition";
import {container, lazyInject} from "../container";
import {IPipelineDataService} from "../dal/pipeline_data.service.interface";
import {IExecutionManager} from "./execution_manager.interface";
import {ISiteDataService} from "../dal/site_data.service.interface";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {ExecutionDefinition} from "../../common/models/execution-definition";
import {v4 as uuidv4} from "uuid";
import {IExecutionDataService} from "../dal/execution_data.service.interface";
import {GetExecutionResultResponse, GetExecutionsResponse} from "../../common/models/execution-request-response";
import {IPipelineExecutorWorker} from "../execution/pipeline-executor-worker";
import {IPipelineExecution, PipelineFinishedEvent, PipelineStartedEvent} from "../execution/pipeline-execution";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {IExecutionContext} from "../execution/pipeline-execution-context";
import {PipelineExecutionResult} from "../execution/pipeline-execution-result";
import {IBackgroundWorker} from "../helpers/background-worker";
import {IExecutionResultDataService} from "../dal/execution-result-data.service.interface";
import {ExecutionDataResult} from "../../common/models/execution-data-result";


@injectable()
export class ExecutionManager implements IExecutionManager, IBackgroundWorker {

    @lazyInject(TYPES.SiteDataService) private readonly siteDataService: ISiteDataService;

    @lazyInject(TYPES.PipelineDataService) private readonly pipelineDataService: IPipelineDataService;

    @lazyInject(TYPES.ExecutionDataService) private readonly executionDataService: IExecutionDataService;

    @lazyInject(TYPES.ExecutionResultDataService) private readonly executionResultDataService: IExecutionResultDataService;

    @lazyInject(TYPES.PipelineExecutorWorker) private readonly pipelineExecutorWorker: IPipelineExecutorWorker;

    private monitoringConfig: { intervalInSec: number; canMonitor: boolean } = { intervalInSec: 10, canMonitor: false }

    private terminatingBackgroundWorker = false;

    id: string;

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    init(options?: any): Promise<void> {

        this.monitoringConfig = JSON.parse(process.env.monitoring);

        this.logger.info(`Monitoring ${this.monitoringConfig.canMonitor ? "Enabled" : "Disabled"}, polling ${this.monitoringConfig.intervalInSec} seconds !`);

        if (this.monitoringConfig.canMonitor) {
            this.scheduleBackgroundWork(() => this.monitorExecutions(), this.monitoringConfig.intervalInSec * 1000, 1234);
        }
        return Promise.resolve();
    }

    private scheduleBackgroundWork(work: () => Promise<any>, interval: number, initialDelay?: number) {

        const schedule = async () => {
            try {
                const promise = work();
                await promise;
            } catch (e) {
                console.error(e);
            } finally {
                if (!this.terminatingBackgroundWorker) setTimeout(schedule, interval);
            }
        };
        setTimeout(() => schedule(), initialDelay || 0);
    }

    terminate(): Promise<void> {
        this.terminatingBackgroundWorker = true;
        return Promise.resolve();
    }

    private async monitorExecutions(): Promise<any> {

        this.logger.info("PipelineExecutorWorker, polling executions ...");
        const pendingExecutions: ExecutionDefinition[] = await this.executionDataService.getExecutions({ status: ExecutionStatus.Pending });

        if (pendingExecutions.length > 0) {
            this.logger.info(`PipelineExecutorWorker, Found ${pendingExecutions.length} executions to run`);
            const promises = pendingExecutions.map(e => {
                this.logger.info(`PipelineExecutorWorker, Schedule execution ${e.key} with pipeline ${e.pipelineId} on site ${e.siteId}`);
                return this.runExecutionBusy(e.key);
            })
            return Promise.all(promises);
        }
        else {
            this.logger.info(`PipelineExecutorWorker, No executions found, will try again in ${this.monitoringConfig.intervalInSec} seconds ...`);
        }
        return this.cancelExpiredExecutions();
    }

    private async cancelExpiredExecutions(): Promise<any> {

        this.logger.info("PipelineExecutorWorker, checking expired executions ...");

        const runningNotHandledExecutions: ExecutionDefinition[] = await this.executionDataService.getExecutions({ status: ExecutionStatus.Running });

        if (runningNotHandledExecutions.length > 0) {
            this.logger.info(`PipelineExecutorWorker, Found ${runningNotHandledExecutions.length} executions to cancel`);
            const promises = runningNotHandledExecutions.map(e => {
                this.logger.info(`PipelineExecutorWorker, Cancelling execution ${e.key} with pipeline ${e.pipelineId} on site ${e.siteId}`);
                return this.updateExecutionStatus(e.key, ExecutionStatus.Cancelled);
            })
            return Promise.all(promises);
        }
        else {
            this.logger.info(`PipelineExecutorWorker, No expired executions found !`);
        }
        return Promise.resolve();
    }

    public async executeSite(siteId: number, pipelineId?: number): Promise<ExecuteSiteResponse> {

        const siteDefinition: SiteDefinition = await this.siteDataService.getSiteById(siteId);

        if (!siteDefinition) {
            return {
                status: RequestStatus.Failed,
                message: "Could not find Site"
            } as ExecuteSiteResponse;
        }

        const pipelineIdToRun = pipelineId || siteDefinition.pipeline.id;

        this.logger.info(`executeSite, marked execution for pipeline ${pipelineIdToRun} on site ${siteDefinition.name}`)

        // Validate Site was not already assigned to running execution
        const siteRunningOrPendingExecution: ExecutionDefinition = await this.executionDataService.getLastExecution(siteId);

        if (siteRunningOrPendingExecution && false === ExecutionStatus.isFinal(siteRunningOrPendingExecution.status)) {
            return {
                status: RequestStatus.Failed,
                message: "Other Site's Execution already scheduled"
            } as ExecuteSiteResponse;
        }

        // Get Pipeline associated with the site
        const pipelineDefinition = await this.pipelineDataService.getPipeline(pipelineIdToRun);

        if (!pipelineDefinition) {
            return {
                status: RequestStatus.Failed,
                message: "Could not find pipeline"
            } as ExecuteSiteResponse;
        }

        const siteExecution: ExecutionDefinition = {
            key: uuidv4(),      // Generate unique UUID
            siteId,
            pipelineId: pipelineIdToRun,
            status: ExecutionStatus.Pending
        }

        return this.executionDataService.addExecution(siteExecution).then((id: number) => {
            return {
                executionInfo: siteExecution,
                status: RequestStatus.Success,
                message: "Execution added Successfully"
            } as ExecuteSiteResponse;
        });
    }

    public async updateExecutionStatus(key: string, newStatus: ExecutionStatus): Promise<boolean> {

        this.logger.info(`Updating Execution ${key} with Status ${newStatus}`)

        return this.executionDataService.updateExecutionStatus(key, newStatus);
    }

    public async getExecutions(filter?: {siteId?: number, key?: string, status?: ExecutionStatus}): Promise<GetExecutionsResponse> {

        const executions: ExecutionDefinition[] = await this.executionDataService.getExecutions(filter);

        return Promise.resolve({
            executions: executions || [],
            status: executions ? RequestStatus.Success : RequestStatus.Failed
        } as GetExecutionsResponse)
    }

    async getExecutionResult(filter?: {executionKey: string}): Promise<GetExecutionResultResponse>{
        const results: ExecutionDataResult[] = await this.executionResultDataService.getResults(filter);

        return Promise.resolve({
            status: RequestStatus.Success,
            results: results
        } as GetExecutionResultResponse)
    }

    private async runExecutionInternal(key: string): Promise<PipelineExecutionResult> {

        const execution: ExecutionDefinition = await this.executionDataService.getExecution(key);

        const site: SiteDefinition = await this.siteDataService.getSiteById(execution.siteId);

        if (!execution || !site) {
            return {
                status: ExecutionStatus.Faulted,
                context: undefined,
                results: []
            };
        }

        const worker: IPipelineExecutorWorker = container.get<IPipelineExecutorWorker>(TYPES.PipelineExecutorWorker);
        const pipelineExecution: IPipelineExecution = await worker.buildExecution(execution);

        pipelineExecution.onPipelineStarted((ev: PipelineStartedEvent) => {
            console.log(`Pipeline ${ev.context.pipelineDef.name} Started at ${ev.context.startTime}`)
        })

        pipelineExecution.onPipelineFinished(async (ev: PipelineFinishedEvent) => {
            console.log(`Pipeline ${ev.context.pipelineDef.name} Finished with Status ${ev.finalStatus} at ${ev.context.endTime}`)
            await this.executionDataService.updateExecutionStatus(ev.context.executionKey, ev.finalStatus);
        })
        return pipelineExecution.execute(site);
    }

    public async runExecutionBusy(key: string): Promise<{context?: IExecutionContext,
        status: RequestStatus,
        message?: string,
        taskResults?: TaskExecutionResult[]}> {

        const execution: ExecutionDefinition = await this.executionDataService.getExecution(key);

        const site: SiteDefinition = await this.siteDataService.getSiteById(execution.siteId);

        if (!execution || !site) {
            return {
                status: RequestStatus.Failed,
                message: "Could not find any Execution or Site associated to Execution"
            };
        }

        return this.runExecutionInternal(key).then((res: PipelineExecutionResult) => {
            return {
                status: res.context.status == ExecutionStatus.Completed ? RequestStatus.Success : RequestStatus.Failed,
                context: res.context,
                results: res.results
            }
        })
    }


}