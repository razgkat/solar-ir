"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const inversify_1 = require("inversify");
const inversify_types_1 = require("../inversify.types");
const request_status_1 = require("../../common/enums/request-status");
const container_1 = require("../container");
const execution_status_1 = require("../../common/enums/execution-status");
const uuid_1 = require("uuid");
let ExecutionManager = class ExecutionManager {
    constructor(logger) {
        this.logger = logger;
        this.monitoringConfig = { intervalInSec: 10, canMonitor: false };
        this.terminatingBackgroundWorker = false;
    }
    init(options) {
        this.monitoringConfig = JSON.parse(process.env.monitoring);
        this.logger.info(`Monitoring ${this.monitoringConfig.canMonitor ? "Enabled" : "Disabled"}, polling ${this.monitoringConfig.intervalInSec} seconds !`);
        if (this.monitoringConfig.canMonitor) {
            this.scheduleBackgroundWork(() => this.monitorExecutions(), this.monitoringConfig.intervalInSec * 1000, 1234);
        }
        return Promise.resolve();
    }
    scheduleBackgroundWork(work, interval, initialDelay) {
        const schedule = () => __awaiter(this, void 0, void 0, function* () {
            try {
                const promise = work();
                yield promise;
            }
            catch (e) {
                console.error(e);
            }
            finally {
                if (!this.terminatingBackgroundWorker)
                    setTimeout(schedule, interval);
            }
        });
        setTimeout(() => schedule(), initialDelay || 0);
    }
    terminate() {
        this.terminatingBackgroundWorker = true;
        return Promise.resolve();
    }
    monitorExecutions() {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.info("PipelineExecutorWorker, polling executions ...");
            const pendingExecutions = yield this.executionDataService.getExecutions({ status: execution_status_1.ExecutionStatus.Pending });
            if (pendingExecutions.length > 0) {
                this.logger.info(`PipelineExecutorWorker, Found ${pendingExecutions.length} executions to run`);
                const promises = pendingExecutions.map(e => {
                    this.logger.info(`PipelineExecutorWorker, Schedule execution ${e.key} with pipeline ${e.pipelineId} on site ${e.siteId}`);
                    return this.runExecutionBusy(e.key);
                });
                return Promise.all(promises);
            }
            else {
                this.logger.info(`PipelineExecutorWorker, No executions found, will try again in ${this.monitoringConfig.intervalInSec} seconds ...`);
            }
            return this.cancelExpiredExecutions();
        });
    }
    cancelExpiredExecutions() {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.info("PipelineExecutorWorker, checking expired executions ...");
            const runningNotHandledExecutions = yield this.executionDataService.getExecutions({ status: execution_status_1.ExecutionStatus.Running });
            if (runningNotHandledExecutions.length > 0) {
                this.logger.info(`PipelineExecutorWorker, Found ${runningNotHandledExecutions.length} executions to cancel`);
                const promises = runningNotHandledExecutions.map(e => {
                    this.logger.info(`PipelineExecutorWorker, Cancelling execution ${e.key} with pipeline ${e.pipelineId} on site ${e.siteId}`);
                    return this.updateExecutionStatus(e.key, execution_status_1.ExecutionStatus.Cancelled);
                });
                return Promise.all(promises);
            }
            else {
                this.logger.info(`PipelineExecutorWorker, No expired executions found !`);
            }
            return Promise.resolve();
        });
    }
    executeSite(siteId, pipelineId) {
        return __awaiter(this, void 0, void 0, function* () {
            const siteDefinition = yield this.siteDataService.getSiteById(siteId);
            if (!siteDefinition) {
                return {
                    status: request_status_1.RequestStatus.Failed,
                    message: "Could not find Site"
                };
            }
            const pipelineIdToRun = pipelineId || siteDefinition.pipeline.id;
            this.logger.info(`executeSite, marked execution for pipeline ${pipelineIdToRun} on site ${siteDefinition.name}`);
            // Validate Site was not already assigned to running execution
            const siteRunningOrPendingExecution = yield this.executionDataService.getLastExecution(siteId);
            if (siteRunningOrPendingExecution && false === execution_status_1.ExecutionStatus.isFinal(siteRunningOrPendingExecution.status)) {
                return {
                    status: request_status_1.RequestStatus.Failed,
                    message: "Other Site's Execution already scheduled"
                };
            }
            // Get Pipeline associated with the site
            const pipelineDefinition = yield this.pipelineDataService.getPipeline(pipelineIdToRun);
            if (!pipelineDefinition) {
                return {
                    status: request_status_1.RequestStatus.Failed,
                    message: "Could not find pipeline"
                };
            }
            const siteExecution = {
                key: uuid_1.v4(),
                siteId,
                pipelineId: pipelineIdToRun,
                status: execution_status_1.ExecutionStatus.Pending
            };
            return this.executionDataService.addExecution(siteExecution).then((id) => {
                return {
                    executionInfo: siteExecution,
                    status: request_status_1.RequestStatus.Success,
                    message: "Execution added Successfully"
                };
            });
        });
    }
    updateExecutionStatus(key, newStatus) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.info(`Updating Execution ${key} with Status ${newStatus}`);
            return this.executionDataService.updateExecutionStatus(key, newStatus);
        });
    }
    getExecutions(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            const executions = yield this.executionDataService.getExecutions(filter);
            return Promise.resolve({
                executions: executions || [],
                status: executions ? request_status_1.RequestStatus.Success : request_status_1.RequestStatus.Failed
            });
        });
    }
    getExecutionResult(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            const results = yield this.executionResultDataService.getResults(filter);
            return Promise.resolve({
                status: request_status_1.RequestStatus.Success,
                results: results
            });
        });
    }
    runExecutionInternal(key) {
        return __awaiter(this, void 0, void 0, function* () {
            const execution = yield this.executionDataService.getExecution(key);
            const site = yield this.siteDataService.getSiteById(execution.siteId);
            if (!execution || !site) {
                return {
                    status: execution_status_1.ExecutionStatus.Faulted,
                    context: undefined,
                    results: []
                };
            }
            const worker = container_1.container.get(inversify_types_1.TYPES.PipelineExecutorWorker);
            const pipelineExecution = yield worker.buildExecution(execution);
            pipelineExecution.onPipelineStarted((ev) => {
                console.log(`Pipeline ${ev.context.pipelineDef.name} Started at ${ev.context.startTime}`);
            });
            pipelineExecution.onPipelineFinished((ev) => __awaiter(this, void 0, void 0, function* () {
                console.log(`Pipeline ${ev.context.pipelineDef.name} Finished with Status ${ev.finalStatus} at ${ev.context.endTime}`);
                yield this.executionDataService.updateExecutionStatus(ev.context.executionKey, ev.finalStatus);
            }));
            return pipelineExecution.execute(site);
        });
    }
    runExecutionBusy(key) {
        return __awaiter(this, void 0, void 0, function* () {
            const execution = yield this.executionDataService.getExecution(key);
            const site = yield this.siteDataService.getSiteById(execution.siteId);
            if (!execution || !site) {
                return {
                    status: request_status_1.RequestStatus.Failed,
                    message: "Could not find any Execution or Site associated to Execution"
                };
            }
            return this.runExecutionInternal(key).then((res) => {
                return {
                    status: res.context.status == execution_status_1.ExecutionStatus.Completed ? request_status_1.RequestStatus.Success : request_status_1.RequestStatus.Failed,
                    context: res.context,
                    results: res.results
                };
            });
        });
    }
};
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.SiteDataService),
    __metadata("design:type", Object)
], ExecutionManager.prototype, "siteDataService", void 0);
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.PipelineDataService),
    __metadata("design:type", Object)
], ExecutionManager.prototype, "pipelineDataService", void 0);
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.ExecutionDataService),
    __metadata("design:type", Object)
], ExecutionManager.prototype, "executionDataService", void 0);
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.ExecutionResultDataService),
    __metadata("design:type", Object)
], ExecutionManager.prototype, "executionResultDataService", void 0);
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.PipelineExecutorWorker),
    __metadata("design:type", Object)
], ExecutionManager.prototype, "pipelineExecutorWorker", void 0);
ExecutionManager = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.inject(inversify_types_1.TYPES.Logger)),
    __metadata("design:paramtypes", [Object])
], ExecutionManager);
exports.ExecutionManager = ExecutionManager;
//# sourceMappingURL=execution_manager.js.map