"use strict";
/*
        Background Worker provide interface to perform periodic task in the background
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=background-worker.js.map