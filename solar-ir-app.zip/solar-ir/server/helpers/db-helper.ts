import {DbRecord} from "../dal/records/db_record";
import {Moment} from "moment";
import moment = require("moment");

export namespace DBHelper {

    export function addWithTimestamps(r: any, time?: Moment): DbRecord {
        const t = time || moment();

        r.updateTime = r.createTime = t.toISOString(true);
        r.updateTimeUtc = r.createTimeUtc = t.unix();
        return r;
    }

    export function removeinternalId(r: DbRecord): any {
       delete r._id; return r;
    }
}