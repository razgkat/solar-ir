"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment");
var DBHelper;
(function (DBHelper) {
    function addWithTimestamps(r, time) {
        const t = time || moment();
        r.updateTime = r.createTime = t.toISOString(true);
        r.updateTimeUtc = r.createTimeUtc = t.unix();
        return r;
    }
    DBHelper.addWithTimestamps = addWithTimestamps;
    function removeinternalId(r) {
        delete r._id;
        return r;
    }
    DBHelper.removeinternalId = removeinternalId;
})(DBHelper = exports.DBHelper || (exports.DBHelper = {}));
//# sourceMappingURL=db-helper.js.map