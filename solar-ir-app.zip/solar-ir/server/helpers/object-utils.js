"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ObjectHelper;
(function (ObjectHelper) {
    function removeNullOrUndefined(obj) {
        return Object.keys(obj)
            .filter(k => obj[k] && obj[k] != null)
            .reduce((acc, k) => { acc[k] = obj[k]; return acc; }, {});
    }
    ObjectHelper.removeNullOrUndefined = removeNullOrUndefined;
})(ObjectHelper = exports.ObjectHelper || (exports.ObjectHelper = {}));
//# sourceMappingURL=object-utils.js.map