

export namespace ObjectHelper {

    export function removeNullOrUndefined<T>(obj: T): T {
        return Object.keys(obj)
            .filter(k => obj[k] && obj[k] != null)
            .reduce((acc, k) => { acc[k] = obj[k]; return acc;},{}) as T;
    }
}