import * as fs from 'fs';
import {injectable} from "inversify";
import {IDBService} from "../dal/data.service.interface";
import {ExecutionDataResult} from "../../common/models/execution-data-result";

export interface ILocalFileWriter extends IDBService {
    write(fileName: string, data: any): Promise<boolean>
}

@injectable()
export class LocalFileWriter implements ILocalFileWriter
{
    public write(fileName: string, data: any): Promise<boolean> {
        return new Promise((resolve, reject) =>  {
            fs.writeFile(fileName, data, function (err) {
                if (err) reject(err);
                resolve(!err);
            });
        });
    }

    saveData(data: ExecutionDataResult, args?: any): Promise<any> {
        return this.write(args.fileName, data);
    }
}