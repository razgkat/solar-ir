/*
        Background Worker provide interface to perform periodic task in the background
 */

export interface IBackgroundWorker {

    init(options?: any): Promise<void>;

    terminate(): Promise<void>;

    readonly id: string
}

