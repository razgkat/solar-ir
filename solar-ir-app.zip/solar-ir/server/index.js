"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = require("dotenv");
const dotenvExpand = require("dotenv-expand");
const server_1 = require("./server");
dotenvExpand(dotenv.config({ path: __dirname + "/.env" }));
process.env.__basedir = __dirname;
try {
    require("./inversify.config").init();
    const server = new server_1.Server();
    server.startServer();
}
catch (e) {
    console.error(e);
}
//# sourceMappingURL=index.js.map