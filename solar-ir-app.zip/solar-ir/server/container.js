"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const inversify_1 = require("inversify");
const inversify_inject_decorators_1 = require("inversify-inject-decorators");
const container = new inversify_1.Container();
exports.container = container;
const { lazyInject } = inversify_inject_decorators_1.default(container, false);
exports.lazyInject = lazyInject;
//# sourceMappingURL=container.js.map