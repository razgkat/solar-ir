/**
 * Solar Irradiance Service Side App
 * This App provides REST API to manage sites and pipelines.
 * The user can create sites and linked those sites into pipeline. Then it can run the pipeline and query the data
 * provided by the pipeline.
 *
 * The App provide basic functionality and can be extended easily, most validations are missing due to the short
 * timing when writing this program.
 *
 * The workflow required to have a successfully execution of pipeline requires:
 * 1. Creating the Site (e.g. "Site1" with ID = 1)
 * 2. Creating the Pipeline  (e.g. "Pipeline1" with ID = 1)
 * 3. Creating Execution by link site to pipeline (e.g. Site1 <-> "Pipeline1"0 --> Getting Execution ID
 * 4. Query Execution Result after completion.
 *
 */
import * as express from "express";
import * as http from "http";
import * as bodyParser from "body-parser"
import {ObjectHelper} from "./helpers/object-utils";
import {container, lazyInject} from "./container";
import {IBackgroundWorker} from "./helpers/background-worker";
import {TYPES} from "./inversify.types";
import {inject} from "inversify";
import {ILogger} from "./managers/logger_manager";

const SITE_MGR_ROUTES = require("./routes/site_manager.routes");
const PIPELINE_MGR_ROUTES = require("./routes/pipeline_manager.routes");
const EXECUTION_MGR_ROUTES = require("./routes/execution_manager.routes");

export class Server{

    private app = express();

    private readonly port:number;

    @lazyInject(TYPES.Logger) private readonly logger: ILogger;

    constructor() {

        this.port = process.env.port ? parseInt(process.env.port) : 3000;
        this.app.use(bodyParser.json({limit:'50mb'})); // support json encoded bodies
        this.app.use(bodyParser.urlencoded({limit:'50mb', extended: true })); // support encoded bodies

        this.initCors();
        this.setRoutes();
        this.setStaticFolders();

        const home = `<p>Solar Irradiance App v1.0.0<br> Status: <p style="color:MediumSeaGreen;">Running ...</p></p>`;
        this.app.get('/', (req, res) => res.type('html').send(home));

        //Must be last
        this.set404Handler();
    }

    private initCors=()=>{
        const cors = require('cors');
        this.app.use(cors());
    };

    public setRoutes=()=>{
        this.app.use("/sites", Server.authenticateCall, SITE_MGR_ROUTES);
        this.app.use("/pipelines", Server.authenticateCall, PIPELINE_MGR_ROUTES);
        this.app.use("/executions", Server.authenticateCall, EXECUTION_MGR_ROUTES);
    };

    public startServer = () => {
        http.createServer(this.app).
            listen(this.port).
            on('error',this.onError).
            on('listening',this.onServerListen);
    };

    public setStaticFolders=()=>{
        const path = require("path");
        this.app.use('/static', express.static(path.join(__dirname, '../client/dist')));
    };

    private onServerListen = ()=>{
        console.log('App listening on port ' + this.port);
        this.initBackgroundWorkers();
    };

    private initBackgroundWorkers() {
        const workers = container.getAll<IBackgroundWorker>(TYPES.BackgroundWorker);
        for (let worker of workers) {
            worker.init().catch(reason => this.logger.error(`Background worker '${worker.id}' error: ${reason}`));
        }
    }

    onError=(err:any)=>{
        switch (err.code) {
            case 'EACCES':
                console.error('port requires elevated privileges');
                process.exit(1);
                break;
            case 'EADDRINUSE':
                console.error('port is already in use');
                process.exit(1);
                break;
            default:
                throw err;
        }
    }

    private set404Handler() {
        this.app.use(function(req, res, next){
            res.status(404).type('txt').send(`Page Not found: ${req.url}`);
        });
    }

    public static authenticateCall(req,res,next) {
        next();
    }
}
