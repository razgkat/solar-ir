"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const task_execution_1 = require("./task-execution");
const execution_status_1 = require("../../common/enums/execution-status");
const container_1 = require("../container");
const inversify_types_1 = require("../inversify.types");
/*
    This task getting solar data and output the data into our Local DB
 */
class NrelSolarDbTaskLoadExecution extends task_execution_1.TaskLoadExecution {
    constructor(definition) {
        super(NrelSolarDbTaskLoadExecution.NAME);
        this.dbService = this.dbServiceProvider.getDbService(definition.input.dbService, definition.input.serviceArgs.dbName);
    }
    load(ctx, inputData) {
        console.log(`Task ${NrelSolarDbTaskLoadExecution.NAME} is Saving ...`);
        // console.log(`------ FINAL DATA ------ ${JSON.stringify(inputData) } ------`);
        return Promise.all(inputData.map(d => this.dbService.saveData(d))).then((res) => {
            return {
                status: execution_status_1.ExecutionStatus.Completed, taskName: this.name, taskUuid: this.uuid, result: inputData
            };
        }, (onRejected) => {
            return {
                status: execution_status_1.ExecutionStatus.Faulted, taskName: this.name, taskUuid: this.uuid, result: inputData
            };
        });
    }
    static create(taskDefinition) {
        return new NrelSolarDbTaskLoadExecution(taskDefinition);
    }
}
NrelSolarDbTaskLoadExecution.NAME = "NrelSolarDbTaskLoad";
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.DBServiceProvider),
    __metadata("design:type", Object)
], NrelSolarDbTaskLoadExecution.prototype, "dbServiceProvider", void 0);
exports.NrelSolarDbTaskLoadExecution = NrelSolarDbTaskLoadExecution;
//# sourceMappingURL=nrel-solar-db-task-load-execution.js.map