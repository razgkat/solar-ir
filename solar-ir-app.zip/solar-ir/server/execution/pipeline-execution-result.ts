import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {IExecutionContext} from "./pipeline-execution-context";
import {ExecutionStatus} from "../../common/enums/execution-status";

/*
    PipelineExecutionResult - represents the result after pipeline ended:
    1. status - Final Status
    2. context - Execution Context contain various information about the last execution
                 such as start and end time
    3. results - Results plotted from each Task in the Pipeline.
*/
export interface PipelineExecutionResult {

    status: ExecutionStatus;
    context: IExecutionContext;
    results?: TaskExecutionResult[];
}