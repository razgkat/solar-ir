"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const execution_status_1 = require("../../common/enums/execution-status");
const file_format_1 = require("../../common/enums/file-format");
const task_execution_1 = require("./task-execution");
const container_1 = require("../container");
const inversify_types_1 = require("../inversify.types");
/*
    This task getting solar data and output the data into CSV or JSON formatting.
 */
class NrelSolarFileTaskLoadExecution extends task_execution_1.TaskLoadExecution {
    constructor(definition) {
        super(NrelSolarFileTaskLoadExecution.NAME);
        this.outputFile = definition.input.outputFile;
        this.fileFormat = definition.input.format;
    }
    load(ctx, inputData) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(`Task ${NrelSolarFileTaskLoadExecution.NAME} outputs results to File ${this.outputFile} ...`);
            let dataToWrite = undefined;
            switch (this.fileFormat) {
                case file_format_1.FileFormat.JSON:
                    dataToWrite = JSON.stringify(inputData);
                    break;
                case file_format_1.FileFormat.CSV:
                    dataToWrite = NrelSolarFileTaskLoadExecution.convertToCsv(inputData);
                    break;
            }
            return this.persistData(ctx, dataToWrite).then(() => {
                return {
                    status: ctx.status,
                    taskName: this.name,
                    taskUuid: this.uuid,
                    result: inputData
                };
            });
        });
    }
    static create(taskDefinition) {
        return new NrelSolarFileTaskLoadExecution(taskDefinition);
    }
    persistData(ctx, inputData) {
        return this.localFileWriter.write(this.outputFile, inputData).then((isSuccess) => __awaiter(this, void 0, void 0, function* () {
            ctx.status = isSuccess ? execution_status_1.ExecutionStatus.Completed : execution_status_1.ExecutionStatus.Faulted;
            yield this.executionResultDataService.saveResult({
                executionKey: ctx.executionKey,
                file: this.outputFile,
                format: this.fileFormat,
                status: ctx.status
            });
        }));
    }
    static convertToCsv(solarMetrics) {
        const columns = Object.keys(solarMetrics[0]);
        let delimitedValues = solarMetrics.map(r => Object.keys(r).map(k => { return (typeof r[k] === "string") ? r[k].replace(',', '|') : r[k]; })).
            map(s => s.join(NrelSolarFileTaskLoadExecution.CSV_DELIMETER)).
            join(NrelSolarFileTaskLoadExecution.CSV_CRLF);
        return columns.join(NrelSolarFileTaskLoadExecution.CSV_DELIMETER) + NrelSolarFileTaskLoadExecution.CSV_CRLF + delimitedValues;
    }
}
NrelSolarFileTaskLoadExecution.NAME = "NrelSolarFileTaskLoad";
NrelSolarFileTaskLoadExecution.CSV_DELIMETER = ',';
NrelSolarFileTaskLoadExecution.CSV_CRLF = '\r\n';
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.LocalFileWriter),
    __metadata("design:type", Object)
], NrelSolarFileTaskLoadExecution.prototype, "localFileWriter", void 0);
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.ExecutionResultDataService),
    __metadata("design:type", Object)
], NrelSolarFileTaskLoadExecution.prototype, "executionResultDataService", void 0);
exports.NrelSolarFileTaskLoadExecution = NrelSolarFileTaskLoadExecution;
//# sourceMappingURL=nrel-solar-file-task-load-execution.js.map