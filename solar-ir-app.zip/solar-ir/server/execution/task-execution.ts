import {TaskType} from "../../common/enums/task-type";
import {v4 as uuid} from "uuid";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {IExecutionContext} from "./pipeline-execution-context";

/*
    Task Execution presents the task workflow in the pipeline, we support 3 types of executions:
    Extract, Transform, Load

    All Task Executions have in common unique uuid (identifier to the execution). the task type (type of executioN)
    The name and the status of the execution updated in real time and in the end.
*/

export abstract class TaskExecution {

    uuid: string;
    type: TaskType;
    name?: string;
    status: ExecutionStatus;

    protected constructor(name: string, type: TaskType) {

        this.uuid = uuid();
        this.type = type;
        this.name = name;
    }

    abstract run(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult>;
}

export abstract class TaskExtractExecution extends TaskExecution {

    protected constructor(name: string) {
        super(name, TaskType.Extract);
    }

    abstract extract(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult>;

    public run(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult> { return this.extract(ctx, inputData) };
}

export abstract class TaskTransformExecution extends TaskExecution {

    protected constructor(name: string) {
        super(name, TaskType.Transform);
    }

    abstract transform(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult>;

    public run(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult> { return this.transform(ctx, inputData) };
}

export abstract class TaskLoadExecution extends TaskExecution {

    protected constructor(name: string) {
        super(name, TaskType.Load);
    }

    abstract load(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult>;

    public run(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult> { return this.load(ctx, inputData) };
}

