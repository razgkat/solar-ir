import {ILogger} from "../managers/logger_manager";
import {PipelineDefinition} from "../../common/models/pipeline-definition";
import {SiteDefinition} from "../../common/models/site-definition";
import {TaskExecution, TaskExtractExecution, TaskLoadExecution, TaskTransformExecution} from "./task-execution";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {TaskType} from "../../common/enums/task-type";
import {ITaskExecutionFactoryProvider} from "./task-factory";
import {PipelineExecutionResult} from "./pipeline-execution-result";
import {IExecutionContext} from "./pipeline-execution-context";
import moment = require("moment");

/*
    PipelineExecution -
    The class manages the pipeline execution, inits the tasks and creating the initial context.
    When execute being called 3 tasks are being executed on after one, the result of the previous task are
    served as input to the next task.

    NOTE:
    For simplicity we have limited the pipeline to hold 3 tasks:
    1. Extract      2. Transform        3. Load

    However, the mechanism doesn't limit us to run any number of tasks as long as each tasks know how to handle
    the input it gets. The code can be easily modified to overcome this limitation adn have an array of tasks
    instead of 3 tasks.
*/

export interface PipelineStartedEvent {
    context: IExecutionContext;
}

export interface PipelineFinishedEvent extends PipelineStartedEvent {
    finalStatus: ExecutionStatus;
}

export interface IPipelineExecution {

    execute(siteDef: SiteDefinition): Promise<PipelineExecutionResult>;

    // Callbacks
    onPipelineStarted(startedEvent: (e: PipelineStartedEvent) => void);

    onPipelineFinished(finishedEvent: (e: PipelineFinishedEvent) => void);
}

export class PipelineExecution implements IPipelineExecution {

    private _tasks:{
        extractTask: TaskExtractExecution,
        transformTask: TaskTransformExecution,
        loadTask: TaskLoadExecution
    };

    private _startEvent: (e: PipelineStartedEvent) => void;

    private _finishEvent: (e: PipelineFinishedEvent) => void;

    constructor(private readonly logger: ILogger,
                private readonly taskFactory: ITaskExecutionFactoryProvider,
                private readonly executionKey: string,
                readonly pipelineDef: PipelineDefinition) {

        this.initTasks();
    }

    private initTasks() {

        let extractTask: TaskExtractExecution = undefined;
        let transformTask: TaskTransformExecution = undefined;
        let loadTask: TaskLoadExecution = undefined;

        if (this.pipelineDef.tasks.extract) {
            extractTask = <any>this.taskFactory.getFactory(TaskType.Extract).create(this.pipelineDef.tasks.extract);
        }

        if (this.pipelineDef.tasks.transform) {
            transformTask = <any>this.taskFactory.getFactory(TaskType.Transform).create(this.pipelineDef.tasks.transform);
        }

        if (this.pipelineDef.tasks.load) {
            loadTask = <any>this.taskFactory.getFactory(TaskType.Load).create(this.pipelineDef.tasks.load);
        }

        this._tasks = {
            extractTask: extractTask,
            transformTask: transformTask,
            loadTask: loadTask
        }
    }

    public onPipelineStarted(startedEvent: (e: PipelineStartedEvent) => void) {
        this._startEvent = startedEvent;
    }

    public onPipelineFinished(finishedEvent: (e: PipelineFinishedEvent) => void) {
        this._finishEvent = finishedEvent;
    }

    private runTask(task: TaskExecution, ctx: IExecutionContext, inputData?: any): Promise<TaskExecutionResult> {

        console.log(`Pipeline Execution: Task ${task.name} Started`);

        return task.run(ctx, inputData).then((taskResult: TaskExecutionResult) => {
            console.log(`Pipeline Execution: Task ${taskResult.taskName} Ended`)
            return taskResult;
        });
    }

    // Run Pipeline !
    public async execute(siteDef: SiteDefinition): Promise<PipelineExecutionResult> {


        this.logger.info(`PipelineExecutor (${this.executionKey}), Pending -> Running`)

        let ctx: IExecutionContext = {

            executionKey: this.executionKey,
            pipelineDef: this.pipelineDef,
            siteDef: siteDef,

            startTime: moment().toISOString(true),
            endTime: undefined,
            status: ExecutionStatus.Running,

            //onTaskStart = this.onTaskStart;
            //onTaskFinish = this.onTaskFinish;
        }

        try {
            // Notify Start of Pipeline Execution
            this.notifyStartPipeline(ctx);

            // EXTRACT TASK - No input data for this task
            const taskExtractResult = await this.runTask(this._tasks.extractTask, ctx);

            if (taskExtractResult.status != ExecutionStatus.Completed) {
                this.logger.error(`PipelineExecutor (${this.executionKey}), task ${taskExtractResult.taskName} not completed, stopping pipeline`)
                this.notifyFinishedPipeline(ctx, ExecutionStatus.Faulted);
                return {context: ctx, results: [taskExtractResult]} as PipelineExecutionResult;
            }

            // TRANSFORM TASK
            const taskTransformResult = await this.runTask(this._tasks.transformTask, ctx, taskExtractResult.result);

            if (taskTransformResult.status != ExecutionStatus.Completed) {
                this.logger.error(`PipelineExecutor (${this.executionKey}), task ${taskTransformResult.taskName} not completed, stopping pipeline`)
                this.notifyFinishedPipeline(ctx, ExecutionStatus.Faulted);
                return {context: ctx, results: [taskExtractResult, taskTransformResult]} as PipelineExecutionResult;
            }

            // LOAD TASK
            const taskLoadResult = await this.runTask(this._tasks.loadTask, ctx, taskTransformResult.result);

            if (taskLoadResult.status != ExecutionStatus.Completed) {
                this.logger.error(`PipelineExecutor (${this.executionKey}), task ${taskLoadResult.taskName} not completed, stopping pipeline`)
                this.notifyFinishedPipeline(ctx, ExecutionStatus.Faulted);
                return {
                    context: ctx,
                    results: [taskExtractResult, taskTransformResult, taskLoadResult]
                } as PipelineExecutionResult;
            }

            // Notify Success on Pipeline Execution
            this.notifyFinishedPipeline(ctx, taskLoadResult.status);
            return {
                context: ctx,
                results: [taskExtractResult, taskTransformResult, taskLoadResult]
            } as PipelineExecutionResult;

        } catch (err) {
            this.notifyFinishedPipeline(ctx, ExecutionStatus.Faulted);
            return {
                context: ctx,
                results: []
            } as PipelineExecutionResult;

        }
    }

    // Events on Starting and Completion

    private notifyStartPipeline(context: IExecutionContext) {
        if (this._startEvent) {
            this._startEvent({ context });
        }
    }

    private notifyFinishedPipeline(context: IExecutionContext, lastStatus: ExecutionStatus) {
        if (this._finishEvent) {
            context.endTime = moment().toISOString(true);
            context.status = lastStatus;
            this._finishEvent({ context, finalStatus: lastStatus })
        }
    }

}