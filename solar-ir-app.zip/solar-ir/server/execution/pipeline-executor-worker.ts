import {ExecutionDefinition} from "../../common/models/execution-definition";
import {lazyInject} from "../container";
import {TYPES} from "../inversify.types";
import {ISiteDataService} from "../dal/site_data.service.interface";
import {IPipelineDataService} from "../dal/pipeline_data.service.interface";
import {inject, injectable} from "inversify";
import {ILogger} from "../managers/logger_manager";
import {IPipelineExecution, PipelineExecution} from "./pipeline-execution";
import {ITaskExecutionFactoryProvider} from "./task-factory";

/*
    IPipelineExecutorWorker provides API for building Pipeline Execution
*/

export interface IPipelineExecutorWorker {
    buildExecution(executionDefinition: ExecutionDefinition): Promise<IPipelineExecution>;
}

@injectable()
export class PipelineExecutorWorker  implements IPipelineExecutorWorker {

    @lazyInject(TYPES.SiteDataService) private readonly siteDataService: ISiteDataService;

    @lazyInject(TYPES.PipelineDataService) private readonly pipelineDataService: IPipelineDataService;

    @lazyInject(TYPES.TaskExecutionFactoryProvider) private readonly taskFactory: ITaskExecutionFactoryProvider;

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    /*
        This function builds the Pipeline by constructing a Pipeline Execution from Definition (Config).
        The Definition contains information about the site and the pipeline.
    */
    public async buildExecution(executionDefinition: ExecutionDefinition): Promise<IPipelineExecution> {

        if (!executionDefinition) {
            this.logger.error("PipelineExecutorBuilder, Execution Definition not provided");
        }

        const siteDef = await this.siteDataService.getSiteById(executionDefinition.siteId);
        const pipelineDef = await this.pipelineDataService.getPipeline(executionDefinition.pipelineId);

        if (!siteDef || !pipelineDef) {
            this.logger.error("PipelineExecutorBuilder, Site or Pipeline are not provided");
            return;
        }
        return new PipelineExecution(this.logger, this.taskFactory, executionDefinition.key, pipelineDef);
    }
}