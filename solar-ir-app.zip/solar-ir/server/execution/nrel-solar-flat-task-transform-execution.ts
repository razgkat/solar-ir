import {TaskTransformExecution} from "./task-execution";
import {NrelSolarFlatTaskTransformDefinition} from "../../common/models/tasks/nrel-solar-flat-task-transform-definition";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {IExecutionContext} from "./pipeline-execution-context";
import {NrelDataConvertors, NrelSolarData} from "../../common/models/nrel-solar/nrel-solar-data";
import {SolarMetric, SolarMetricType} from "../../common/models/solar-metric";
import {SolarPeriod} from "../../common/enums/solar-period";
import NrelPeriodVals = NrelDataConvertors.NrelPeriodVals;

/*
    NrelSolarFlatTaskTransformExecution

    This task transform the solar data arrived from NREL Web Api into list of records where each
    record contains:

        siteName: string;
        siteId: number;
        pipelineName: string;
        pipelineId: number;
        source: string;
        version: string,
        type: SolarMetricType;
        period: SolarPeriod;
        value: number;


*/
export class NrelSolarFlatTaskTransformExecution extends TaskTransformExecution {

    public static NAME = "NrelSolarFlatTaskTransform";

    constructor(definition: NrelSolarFlatTaskTransformDefinition) {
        super(NrelSolarFlatTaskTransformExecution.NAME);
    }

    transform(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult> {

        const solarData: NrelSolarData = inputData[0] as NrelSolarData;

        console.log(`Task ${NrelSolarFlatTaskTransformExecution.NAME} is Transforming ...`);

        return Promise.resolve({
            status: ExecutionStatus.Completed, taskName: this.name, taskUuid: this.uuid, result: this.buildSolarMetricRecordsFromNrelSolarData(solarData, ctx)
        });
    }

    /*
        Transform the Solar Data Json into array of records of type SolarMetric
     */
    private buildSolarMetricRecordsFromNrelSolarData(solarData: NrelSolarData, ctx: IExecutionContext): SolarMetric[] {

        const sourcesJoined = solarData.metadata.sources.join('|');

        const avg_dni_records:SolarMetric[] = Object.keys(solarData.outputs.avg_dni.monthly).map((month: NrelPeriodVals) => {
            return {
                siteName: ctx.siteDef.name,
                siteId: ctx.siteDef.id,
                pipelineName: ctx.pipelineDef.name,
                pipelineId: ctx.pipelineDef.id,
                executionKey: ctx.executionKey,
                source: sourcesJoined,
                version: solarData.version,
                type: SolarMetricType.AVG_DNI,
                period: NrelDataConvertors.fromPeriodStringToMappedValue(month),
                value: solarData.outputs.avg_dni.monthly[month]
            }
        })

        const avg_ghi_records:SolarMetric[] = Object.keys(solarData.outputs.avg_ghi.monthly).map((month: NrelPeriodVals) => {
            return {
                siteName: ctx.siteDef.name,
                siteId: ctx.siteDef.id,
                pipelineName: ctx.pipelineDef.name,
                pipelineId: ctx.pipelineDef.id,
                executionKey: ctx.executionKey,
                source: sourcesJoined,
                version: solarData.version,
                type: SolarMetricType.AVG_GHI,
                period: NrelDataConvertors.fromPeriodStringToMappedValue(month),
                value: solarData.outputs.avg_dni.monthly[month]
            }
        })

        const avg_lat_tilt_records:SolarMetric[] = Object.keys(solarData.outputs.avg_lat_tilt.monthly).map((month: NrelPeriodVals) => {
            return {
                siteName: ctx.siteDef.name,
                siteId: ctx.siteDef.id,
                pipelineName: ctx.pipelineDef.name,
                pipelineId: ctx.pipelineDef.id,
                executionKey: ctx.executionKey,
                source: sourcesJoined,
                version: solarData.version,
                type: SolarMetricType.AVG_LAT_TILT,
                period: NrelDataConvertors.fromPeriodStringToMappedValue(month),
                value: solarData.outputs.avg_dni.monthly[month]
            }
        })

        // Add Annual Period
        avg_dni_records.push({
            siteName: ctx.siteDef.name,
            siteId: ctx.siteDef.id,
            pipelineName: ctx.pipelineDef.name,
            pipelineId: ctx.pipelineDef.id,
            executionKey: ctx.executionKey,
            source: sourcesJoined,
            version: solarData.version,
            type: SolarMetricType.AVG_DNI,
            period: SolarPeriod.Annual,
            value: solarData.outputs.avg_dni.annual
        })

        avg_ghi_records.push({
            siteName: ctx.siteDef.name,
            siteId: ctx.siteDef.id,
            pipelineName: ctx.pipelineDef.name,
            pipelineId: ctx.pipelineDef.id,
            executionKey: ctx.executionKey,
            source: sourcesJoined,
            version: solarData.version,
            type: SolarMetricType.AVG_GHI,
            period: SolarPeriod.Annual,
            value: solarData.outputs.avg_ghi.annual
        })

        avg_lat_tilt_records.push({
            siteName: ctx.siteDef.name,
            siteId: ctx.siteDef.id,
            pipelineName: ctx.pipelineDef.name,
            pipelineId: ctx.pipelineDef.id,
            executionKey: ctx.executionKey,
            source: sourcesJoined,
            version: solarData.version,
            type: SolarMetricType.AVG_LAT_TILT,
            period: SolarPeriod.Annual,
            value: solarData.outputs.avg_lat_tilt.annual
        })

        const transformedData: SolarMetric[]  = [...avg_dni_records, ...avg_dni_records, ...avg_lat_tilt_records];
        return transformedData;
    }

    public static create(taskDefinition: NrelSolarFlatTaskTransformDefinition): NrelSolarFlatTaskTransformExecution {
        return new NrelSolarFlatTaskTransformExecution(taskDefinition);
    }

}
