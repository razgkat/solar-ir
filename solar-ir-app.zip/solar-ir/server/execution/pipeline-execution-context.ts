import {PipelineDefinition} from "../../common/models/pipeline-definition";
import {SiteDefinition} from "../../common/models/site-definition";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {ExecutionStatus} from "../../common/enums/execution-status";

export interface IExecutionContext {

    executionKey: string;
    pipelineDef: PipelineDefinition;
    siteDef: SiteDefinition;

    startTime: string,
    endTime: string,
    status: ExecutionStatus;

    // Callbacks
    onTaskStart?: (taskUuid: string) => void;
    onTaskFinish?: (result: TaskExecutionResult) => void;
}
