import {
    NRELSolarDataInputFormats,
    NrelSolarHttpTaskExtractDefinition
} from "../../common/models/tasks/nrel-solar-http-task-extract-definition";
import {TaskExtractExecution} from "./task-execution";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {IExecutionContext} from "./pipeline-execution-context";
import {SiteDefinition} from "../../common/models/site-definition";
import {NrelSolarData} from "../../common/models/nrel-solar/nrel-solar-data";

const request = require('request');

/*
    NrelSolarHttpTaskExtractExecution

    This task responsible on fetching Solar Data from NREL Web API
*/
export class NrelSolarHttpTaskExtractExecution extends TaskExtractExecution {

    public static NAME = "NrelSolarHttpTaskExtract";

    private uri: string;
    private port: number;
    private version: number;
    private format: NRELSolarDataInputFormats;
    private api_key: string;

    // https://developer.nrel.gov/api/solar/solar_resource/v1.json?api_key=DEMO_KEY&lat=40&lon=-105
    private buildHttpRequestUrl = (site: SiteDefinition):string => {
        return `${this.uri}/v${this.version}.${this.format}?api_key=${this.api_key}&lat=${site.location.lat}&lon=${site.location.lon}`
    }

    constructor(definition: NrelSolarHttpTaskExtractDefinition) {
        super(NrelSolarHttpTaskExtractExecution.NAME);

        this.uri = definition.input.uri;
        this.port = definition.input.port;
        this.version = definition.input.version;
        this.format = definition.input.format;
        this.api_key = definition.input.uriParameters.api_key;
    }

    async extract(ctx: IExecutionContext, inputData?: any): Promise<TaskExecutionResult> {

        console.log(`Task ${NrelSolarHttpTaskExtractExecution.NAME} is fetchiing data ...`);

        const solarData = await this.getSolarData<NrelSolarData>(ctx.siteDef);

        return Promise.resolve({
            status: ExecutionStatus.Completed,
            taskName: this.name,
            taskUuid: this.uuid,
            result: [ solarData ]
        });
    }

    public static create(taskDefinition: NrelSolarHttpTaskExtractDefinition): NrelSolarHttpTaskExtractExecution {
        return new NrelSolarHttpTaskExtractExecution(taskDefinition);
    }


    private async getSolarData<T>(site: SiteDefinition): Promise<T> {

        return new Promise<T>((resolve, reject) => {
            request(this.buildHttpRequestUrl(site), {json: true}, (err, res, body) => {
                if (err) {
                    console.log(err);
                    reject(err);
                }
                resolve(body);
            })
        });
    }
}

