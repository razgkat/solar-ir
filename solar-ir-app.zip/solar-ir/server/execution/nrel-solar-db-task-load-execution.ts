import {TaskLoadExecution} from "./task-execution";
import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {IExecutionContext} from "./pipeline-execution-context";
import {IDBServiceProvider} from "../dal/data-service-provider";
import {lazyInject} from "../container";
import {TYPES} from "../inversify.types";
import {IDBService} from "../dal/data.service.interface";
import {DbServiceType} from "../../common/enums/db-service-type";
import {NrelSolarDbTaskLoadDefinition} from "../../common/models/tasks/nrel-solar-db-task-load-definition";

/*
    This task getting solar data and output the data into our Local DB
 */
export class NrelSolarDbTaskLoadExecution extends TaskLoadExecution {

    public static NAME = "NrelSolarDbTaskLoad";

    private dbService: IDBService;

    @lazyInject(TYPES.DBServiceProvider) private readonly dbServiceProvider: IDBServiceProvider;

    constructor(definition: NrelSolarDbTaskLoadDefinition) {
        super(NrelSolarDbTaskLoadExecution.NAME);

        this.dbService = this.dbServiceProvider.getDbService(definition.input.dbService as DbServiceType, definition.input.serviceArgs.dbName);
    }

    load(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult> {

        console.log(`Task ${NrelSolarDbTaskLoadExecution.NAME} is Saving ...`);

        // console.log(`------ FINAL DATA ------ ${JSON.stringify(inputData) } ------`);
        return Promise.all(inputData.map(d => this.dbService.saveData(d))).then(
            (res) => {
                return {
                    status: ExecutionStatus.Completed, taskName: this.name, taskUuid: this.uuid, result: inputData
                }
            },
            (onRejected) => {
                return {
                    status: ExecutionStatus.Faulted, taskName: this.name, taskUuid: this.uuid, result: inputData
                }
            }
        );
    }

    public static create(taskDefinition: NrelSolarDbTaskLoadDefinition): NrelSolarDbTaskLoadExecution {
        return new NrelSolarDbTaskLoadExecution(taskDefinition);
    }

}

