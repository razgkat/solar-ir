import {TaskExecutionResult} from "../../common/models/tasks/TaskExecutionResult";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {IExecutionContext} from "./pipeline-execution-context";
import {NrelSolarFileTaskLoadDefinition} from "../../common/models/tasks/nrel-solar-file-task-load-definition";
import {FileFormat} from "../../common/enums/file-format";
import {SolarMetric} from "../../common/models/solar-metric";
import {TaskLoadExecution} from "./task-execution";
import {lazyInject} from "../container";
import {TYPES} from "../inversify.types";
import {ILocalFileWriter} from "../helpers/storage-utils";
import {IExecutionResultDataService} from "../dal/execution-result-data.service.interface";

/*
    This task getting solar data and output the data into CSV or JSON formatting.
 */
export class NrelSolarFileTaskLoadExecution extends TaskLoadExecution {

    public static NAME = "NrelSolarFileTaskLoad";

    private static CSV_DELIMETER = ',';
    private static CSV_CRLF = '\r\n';

    private readonly outputFile: string;
    private readonly fileFormat: FileFormat;

    @lazyInject(TYPES.LocalFileWriter) private readonly localFileWriter: ILocalFileWriter;

    @lazyInject(TYPES.ExecutionResultDataService) private readonly executionResultDataService: IExecutionResultDataService;

    constructor(definition: NrelSolarFileTaskLoadDefinition) {
        super(NrelSolarFileTaskLoadExecution.NAME);

        this.outputFile = definition.input.outputFile;
        this.fileFormat = definition.input.format;
    }

    async load(ctx: IExecutionContext, inputData?: any[]): Promise<TaskExecutionResult> {

        console.log(`Task ${NrelSolarFileTaskLoadExecution.NAME} outputs results to File ${this.outputFile} ...`);

        let dataToWrite = undefined;

        switch(this.fileFormat) {
            case FileFormat.JSON:
                dataToWrite = JSON.stringify(inputData);
                break;

            case FileFormat.CSV:
                dataToWrite = NrelSolarFileTaskLoadExecution.convertToCsv(inputData as SolarMetric[]);
                break;
        }

        return this.persistData(ctx, dataToWrite).then(() => {
            return {
                status: ctx.status,
                taskName: this.name,
                taskUuid: this.uuid,
                result: inputData
            };
        })
    }

    public static create(taskDefinition: NrelSolarFileTaskLoadDefinition): NrelSolarFileTaskLoadExecution {
        return new NrelSolarFileTaskLoadExecution(taskDefinition);
    }

    private persistData(ctx: IExecutionContext, inputData: any[]): Promise<void> {

        return this.localFileWriter.write(this.outputFile, inputData).then( async (isSuccess: boolean) => {

            ctx.status = isSuccess ? ExecutionStatus.Completed : ExecutionStatus.Faulted;
            await this.executionResultDataService.saveResult({
                executionKey: ctx.executionKey,
                file: this.outputFile,
                format: this.fileFormat,
                status: ctx.status
            });

        });
    }

    private static convertToCsv(solarMetrics: SolarMetric[]): string {
        const columns = Object.keys(solarMetrics[0]);

        let delimitedValues =
            solarMetrics.map(r => Object.keys(r).map(k => { return (typeof r[k] === "string") ? r[k].replace(',', '|') : r[k] })).
            map(s => s.join(NrelSolarFileTaskLoadExecution.CSV_DELIMETER)).
            join(NrelSolarFileTaskLoadExecution.CSV_CRLF)

        return columns.join(NrelSolarFileTaskLoadExecution.CSV_DELIMETER) + NrelSolarFileTaskLoadExecution.CSV_CRLF +  delimitedValues;
    }

}

