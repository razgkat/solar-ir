"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const task_type_1 = require("../../common/enums/task-type");
const uuid_1 = require("uuid");
/*
    Task Execution presents the task workflow in the pipeline, we support 3 types of executions:
    Extract, Transform, Load

    All Task Executions have in common unique uuid (identifier to the execution). the task type (type of executioN)
    The name and the status of the execution updated in real time and in the end.
*/
class TaskExecution {
    constructor(name, type) {
        this.uuid = uuid_1.v4();
        this.type = type;
        this.name = name;
    }
}
exports.TaskExecution = TaskExecution;
class TaskExtractExecution extends TaskExecution {
    constructor(name) {
        super(name, task_type_1.TaskType.Extract);
    }
    run(ctx, inputData) { return this.extract(ctx, inputData); }
    ;
}
exports.TaskExtractExecution = TaskExtractExecution;
class TaskTransformExecution extends TaskExecution {
    constructor(name) {
        super(name, task_type_1.TaskType.Transform);
    }
    run(ctx, inputData) { return this.transform(ctx, inputData); }
    ;
}
exports.TaskTransformExecution = TaskTransformExecution;
class TaskLoadExecution extends TaskExecution {
    constructor(name) {
        super(name, task_type_1.TaskType.Load);
    }
    run(ctx, inputData) { return this.load(ctx, inputData); }
    ;
}
exports.TaskLoadExecution = TaskLoadExecution;
//# sourceMappingURL=task-execution.js.map