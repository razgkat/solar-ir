import {TaskType} from "../../common/enums/task-type";
import {TaskExecution, TaskExtractExecution, TaskTransformExecution} from "./task-execution";
import {NrelSolarHttpTaskExtractExecution} from "./nrel-solar-http-task-extract-execution";
import {NrelSolarFlatTaskTransformExecution} from "./nrel-solar-flat-task-transform-execution";
import {NrelSolarDbTaskLoadExecution} from "./nrel-solar-db-task-load-execution";
import {inject, injectable} from "inversify";
import {TYPES} from "../inversify.types";
import {ILogger} from "../managers/logger_manager";
import {TaskDefinition} from "../../common/models/tasks/task-definition";
import {NrelSolarFileTaskLoadExecution} from "./nrel-solar-file-task-load-execution";

/*
    Provides API for creating Task Execution Instance from Configuration (Definition)
    The Task Execution handles the task processing in the pipeline.
*/
export interface ITaskExecutionFactory {
    create(taskDefinition?: TaskDefinition): TaskExecution;
}

/*
    Provides API for getting the Task Execution Factory
*/
export interface ITaskExecutionFactoryProvider {
    getFactory(taskType: TaskType):ITaskExecutionFactory;
}

/*
    The Task Execution Factory which provides functionality for creating
    all types of tasks in the ETL.

    Each task type is associated with unique "Name" used when defining the pipeline.
    There should not be conflict between different tasks sharing the same name,
*/
@injectable()
export class TaskExecutionFactoryProvider implements  ITaskExecutionFactoryProvider {

    constructor(@inject(TYPES.Logger) private readonly logger: ILogger) { }

    // Extract
    private static TASK_EXTRACT_EXECUTION_FACTORY = new class TaskExtractExecutionFactory {

        private readonly taskNameToTaskCreateMap = new Map<string, Function>([
            [NrelSolarHttpTaskExtractExecution.NAME, NrelSolarHttpTaskExtractExecution.create],
        ]);

        public create(taskDefinition?: TaskDefinition): TaskExtractExecution {
            const createFn = this.taskNameToTaskCreateMap.get(taskDefinition.name);
            return createFn ? createFn(taskDefinition) : undefined;
        }

    } as ITaskExecutionFactory;

    // Transform
    private static TASK_TRANSFORM_EXECUTION_FACTORY = new class TaskTransformExecutionFactory {

        private readonly taskNameToTaskCreateMap = new Map<string, Function>([
            [NrelSolarFlatTaskTransformExecution.NAME, NrelSolarFlatTaskTransformExecution.create],
        ]);

        public create(taskDefinition?: TaskDefinition): TaskTransformExecution {
            const createFn = this.taskNameToTaskCreateMap.get(taskDefinition.name);
            return createFn ? createFn(taskDefinition) : undefined;
        }

    } as ITaskExecutionFactory;

    // Load
    private static TASK_LOAD_EXECUTION_FACTORY = new class TaskLoadExecutionFactory {

        private readonly taskNameToTaskCreateMap = new Map<string, Function>([
            [NrelSolarDbTaskLoadExecution.NAME, NrelSolarDbTaskLoadExecution.create],
            [NrelSolarFileTaskLoadExecution.NAME, NrelSolarFileTaskLoadExecution.create]
        ]);

        public create(taskDefinition?: TaskDefinition): TaskTransformExecution {
            const createFn = this.taskNameToTaskCreateMap.get(taskDefinition.name);
            return createFn ? createFn(taskDefinition) : undefined;
        }

    } as ITaskExecutionFactory;

    // Mapping Task Type to Factory
    private readonly taskTypeToFactoryMap = new Map<TaskType, Function>([
        [TaskType.Extract,      () => TaskExecutionFactoryProvider.TASK_EXTRACT_EXECUTION_FACTORY],
        [TaskType.Transform,    () => TaskExecutionFactoryProvider.TASK_TRANSFORM_EXECUTION_FACTORY],
        [TaskType.Load,         () => TaskExecutionFactoryProvider.TASK_LOAD_EXECUTION_FACTORY]
    ]);

    public getFactory(taskType: TaskType):ITaskExecutionFactory {
        const factory = this.taskTypeToFactoryMap.get(taskType);
        return factory ? factory() : undefined;
    }
}