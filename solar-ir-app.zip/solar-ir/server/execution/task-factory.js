"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var TaskExecutionFactoryProvider_1;
const task_type_1 = require("../../common/enums/task-type");
const nrel_solar_http_task_extract_execution_1 = require("./nrel-solar-http-task-extract-execution");
const nrel_solar_flat_task_transform_execution_1 = require("./nrel-solar-flat-task-transform-execution");
const nrel_solar_db_task_load_execution_1 = require("./nrel-solar-db-task-load-execution");
const inversify_1 = require("inversify");
const inversify_types_1 = require("../inversify.types");
const nrel_solar_file_task_load_execution_1 = require("./nrel-solar-file-task-load-execution");
/*
    The Task Execution Factory which provides functionality for creating
    all types of tasks in the ETL.

    Each task type is associated with unique "Name" used when defining the pipeline.
    There should not be conflict between different tasks sharing the same name,
*/
let TaskExecutionFactoryProvider = TaskExecutionFactoryProvider_1 = class TaskExecutionFactoryProvider {
    constructor(logger) {
        this.logger = logger;
        // Mapping Task Type to Factory
        this.taskTypeToFactoryMap = new Map([
            [task_type_1.TaskType.Extract, () => TaskExecutionFactoryProvider_1.TASK_EXTRACT_EXECUTION_FACTORY],
            [task_type_1.TaskType.Transform, () => TaskExecutionFactoryProvider_1.TASK_TRANSFORM_EXECUTION_FACTORY],
            [task_type_1.TaskType.Load, () => TaskExecutionFactoryProvider_1.TASK_LOAD_EXECUTION_FACTORY]
        ]);
    }
    getFactory(taskType) {
        const factory = this.taskTypeToFactoryMap.get(taskType);
        return factory ? factory() : undefined;
    }
};
// Extract
TaskExecutionFactoryProvider.TASK_EXTRACT_EXECUTION_FACTORY = new class TaskExtractExecutionFactory {
    constructor() {
        this.taskNameToTaskCreateMap = new Map([
            [nrel_solar_http_task_extract_execution_1.NrelSolarHttpTaskExtractExecution.NAME, nrel_solar_http_task_extract_execution_1.NrelSolarHttpTaskExtractExecution.create],
        ]);
    }
    create(taskDefinition) {
        const createFn = this.taskNameToTaskCreateMap.get(taskDefinition.name);
        return createFn ? createFn(taskDefinition) : undefined;
    }
};
// Transform
TaskExecutionFactoryProvider.TASK_TRANSFORM_EXECUTION_FACTORY = new class TaskTransformExecutionFactory {
    constructor() {
        this.taskNameToTaskCreateMap = new Map([
            [nrel_solar_flat_task_transform_execution_1.NrelSolarFlatTaskTransformExecution.NAME, nrel_solar_flat_task_transform_execution_1.NrelSolarFlatTaskTransformExecution.create],
        ]);
    }
    create(taskDefinition) {
        const createFn = this.taskNameToTaskCreateMap.get(taskDefinition.name);
        return createFn ? createFn(taskDefinition) : undefined;
    }
};
// Load
TaskExecutionFactoryProvider.TASK_LOAD_EXECUTION_FACTORY = new class TaskLoadExecutionFactory {
    constructor() {
        this.taskNameToTaskCreateMap = new Map([
            [nrel_solar_db_task_load_execution_1.NrelSolarDbTaskLoadExecution.NAME, nrel_solar_db_task_load_execution_1.NrelSolarDbTaskLoadExecution.create],
            [nrel_solar_file_task_load_execution_1.NrelSolarFileTaskLoadExecution.NAME, nrel_solar_file_task_load_execution_1.NrelSolarFileTaskLoadExecution.create]
        ]);
    }
    create(taskDefinition) {
        const createFn = this.taskNameToTaskCreateMap.get(taskDefinition.name);
        return createFn ? createFn(taskDefinition) : undefined;
    }
};
TaskExecutionFactoryProvider = TaskExecutionFactoryProvider_1 = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.inject(inversify_types_1.TYPES.Logger)),
    __metadata("design:paramtypes", [Object])
], TaskExecutionFactoryProvider);
exports.TaskExecutionFactoryProvider = TaskExecutionFactoryProvider;
//# sourceMappingURL=task-factory.js.map