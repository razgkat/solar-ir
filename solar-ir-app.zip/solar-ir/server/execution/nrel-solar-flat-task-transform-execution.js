"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const task_execution_1 = require("./task-execution");
const execution_status_1 = require("../../common/enums/execution-status");
const nrel_solar_data_1 = require("../../common/models/nrel-solar/nrel-solar-data");
const solar_metric_1 = require("../../common/models/solar-metric");
const solar_period_1 = require("../../common/enums/solar-period");
/*
    NrelSolarFlatTaskTransformExecution

    This task transform the solar data arrived from NREL Web Api into list of records where each
    record contains:

        siteName: string;
        siteId: number;
        pipelineName: string;
        pipelineId: number;
        source: string;
        version: string,
        type: SolarMetricType;
        period: SolarPeriod;
        value: number;


*/
class NrelSolarFlatTaskTransformExecution extends task_execution_1.TaskTransformExecution {
    constructor(definition) {
        super(NrelSolarFlatTaskTransformExecution.NAME);
    }
    transform(ctx, inputData) {
        const solarData = inputData[0];
        console.log(`Task ${NrelSolarFlatTaskTransformExecution.NAME} is Transforming ...`);
        return Promise.resolve({
            status: execution_status_1.ExecutionStatus.Completed, taskName: this.name, taskUuid: this.uuid, result: this.buildSolarMetricRecordsFromNrelSolarData(solarData, ctx)
        });
    }
    /*
        Transform the Solar Data Json into array of records of type SolarMetric
     */
    buildSolarMetricRecordsFromNrelSolarData(solarData, ctx) {
        const sourcesJoined = solarData.metadata.sources.join('|');
        const avg_dni_records = Object.keys(solarData.outputs.avg_dni.monthly).map((month) => {
            return {
                siteName: ctx.siteDef.name,
                siteId: ctx.siteDef.id,
                pipelineName: ctx.pipelineDef.name,
                pipelineId: ctx.pipelineDef.id,
                executionKey: ctx.executionKey,
                source: sourcesJoined,
                version: solarData.version,
                type: solar_metric_1.SolarMetricType.AVG_DNI,
                period: nrel_solar_data_1.NrelDataConvertors.fromPeriodStringToMappedValue(month),
                value: solarData.outputs.avg_dni.monthly[month]
            };
        });
        const avg_ghi_records = Object.keys(solarData.outputs.avg_ghi.monthly).map((month) => {
            return {
                siteName: ctx.siteDef.name,
                siteId: ctx.siteDef.id,
                pipelineName: ctx.pipelineDef.name,
                pipelineId: ctx.pipelineDef.id,
                executionKey: ctx.executionKey,
                source: sourcesJoined,
                version: solarData.version,
                type: solar_metric_1.SolarMetricType.AVG_GHI,
                period: nrel_solar_data_1.NrelDataConvertors.fromPeriodStringToMappedValue(month),
                value: solarData.outputs.avg_dni.monthly[month]
            };
        });
        const avg_lat_tilt_records = Object.keys(solarData.outputs.avg_lat_tilt.monthly).map((month) => {
            return {
                siteName: ctx.siteDef.name,
                siteId: ctx.siteDef.id,
                pipelineName: ctx.pipelineDef.name,
                pipelineId: ctx.pipelineDef.id,
                executionKey: ctx.executionKey,
                source: sourcesJoined,
                version: solarData.version,
                type: solar_metric_1.SolarMetricType.AVG_LAT_TILT,
                period: nrel_solar_data_1.NrelDataConvertors.fromPeriodStringToMappedValue(month),
                value: solarData.outputs.avg_dni.monthly[month]
            };
        });
        // Add Annual Period
        avg_dni_records.push({
            siteName: ctx.siteDef.name,
            siteId: ctx.siteDef.id,
            pipelineName: ctx.pipelineDef.name,
            pipelineId: ctx.pipelineDef.id,
            executionKey: ctx.executionKey,
            source: sourcesJoined,
            version: solarData.version,
            type: solar_metric_1.SolarMetricType.AVG_DNI,
            period: solar_period_1.SolarPeriod.Annual,
            value: solarData.outputs.avg_dni.annual
        });
        avg_ghi_records.push({
            siteName: ctx.siteDef.name,
            siteId: ctx.siteDef.id,
            pipelineName: ctx.pipelineDef.name,
            pipelineId: ctx.pipelineDef.id,
            executionKey: ctx.executionKey,
            source: sourcesJoined,
            version: solarData.version,
            type: solar_metric_1.SolarMetricType.AVG_GHI,
            period: solar_period_1.SolarPeriod.Annual,
            value: solarData.outputs.avg_ghi.annual
        });
        avg_lat_tilt_records.push({
            siteName: ctx.siteDef.name,
            siteId: ctx.siteDef.id,
            pipelineName: ctx.pipelineDef.name,
            pipelineId: ctx.pipelineDef.id,
            executionKey: ctx.executionKey,
            source: sourcesJoined,
            version: solarData.version,
            type: solar_metric_1.SolarMetricType.AVG_LAT_TILT,
            period: solar_period_1.SolarPeriod.Annual,
            value: solarData.outputs.avg_lat_tilt.annual
        });
        const transformedData = [...avg_dni_records, ...avg_dni_records, ...avg_lat_tilt_records];
        return transformedData;
    }
    static create(taskDefinition) {
        return new NrelSolarFlatTaskTransformExecution(taskDefinition);
    }
}
NrelSolarFlatTaskTransformExecution.NAME = "NrelSolarFlatTaskTransform";
exports.NrelSolarFlatTaskTransformExecution = NrelSolarFlatTaskTransformExecution;
//# sourceMappingURL=nrel-solar-flat-task-transform-execution.js.map