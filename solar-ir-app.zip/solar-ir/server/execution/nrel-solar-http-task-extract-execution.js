"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const task_execution_1 = require("./task-execution");
const execution_status_1 = require("../../common/enums/execution-status");
const request = require('request');
/*
    NrelSolarHttpTaskExtractExecution

    This task responsible on fetching Solar Data from NREL Web API
*/
class NrelSolarHttpTaskExtractExecution extends task_execution_1.TaskExtractExecution {
    constructor(definition) {
        super(NrelSolarHttpTaskExtractExecution.NAME);
        // https://developer.nrel.gov/api/solar/solar_resource/v1.json?api_key=DEMO_KEY&lat=40&lon=-105
        this.buildHttpRequestUrl = (site) => {
            return `${this.uri}/v${this.version}.${this.format}?api_key=${this.api_key}&lat=${site.location.lat}&lon=${site.location.lon}`;
        };
        this.uri = definition.input.uri;
        this.port = definition.input.port;
        this.version = definition.input.version;
        this.format = definition.input.format;
        this.api_key = definition.input.uriParameters.api_key;
    }
    extract(ctx, inputData) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(`Task ${NrelSolarHttpTaskExtractExecution.NAME} is fetchiing data ...`);
            const solarData = yield this.getSolarData(ctx.siteDef);
            return Promise.resolve({
                status: execution_status_1.ExecutionStatus.Completed,
                taskName: this.name,
                taskUuid: this.uuid,
                result: [solarData]
            });
        });
    }
    static create(taskDefinition) {
        return new NrelSolarHttpTaskExtractExecution(taskDefinition);
    }
    getSolarData(site) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                request(this.buildHttpRequestUrl(site), { json: true }, (err, res, body) => {
                    if (err) {
                        console.log(err);
                        reject(err);
                    }
                    resolve(body);
                });
            });
        });
    }
}
NrelSolarHttpTaskExtractExecution.NAME = "NrelSolarHttpTaskExtract";
exports.NrelSolarHttpTaskExtractExecution = NrelSolarHttpTaskExtractExecution;
//# sourceMappingURL=nrel-solar-http-task-extract-execution.js.map