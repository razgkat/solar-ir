"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const execution_status_1 = require("../../common/enums/execution-status");
const task_type_1 = require("../../common/enums/task-type");
const moment = require("moment");
class PipelineExecution {
    constructor(logger, taskFactory, executionKey, pipelineDef) {
        this.logger = logger;
        this.taskFactory = taskFactory;
        this.executionKey = executionKey;
        this.pipelineDef = pipelineDef;
        this.initTasks();
    }
    initTasks() {
        let extractTask = undefined;
        let transformTask = undefined;
        let loadTask = undefined;
        if (this.pipelineDef.tasks.extract) {
            extractTask = this.taskFactory.getFactory(task_type_1.TaskType.Extract).create(this.pipelineDef.tasks.extract);
        }
        if (this.pipelineDef.tasks.transform) {
            transformTask = this.taskFactory.getFactory(task_type_1.TaskType.Transform).create(this.pipelineDef.tasks.transform);
        }
        if (this.pipelineDef.tasks.load) {
            loadTask = this.taskFactory.getFactory(task_type_1.TaskType.Load).create(this.pipelineDef.tasks.load);
        }
        this._tasks = {
            extractTask: extractTask,
            transformTask: transformTask,
            loadTask: loadTask
        };
    }
    onPipelineStarted(startedEvent) {
        this._startEvent = startedEvent;
    }
    onPipelineFinished(finishedEvent) {
        this._finishEvent = finishedEvent;
    }
    runTask(task, ctx, inputData) {
        console.log(`Pipeline Execution: Task ${task.name} Started`);
        return task.run(ctx, inputData).then((taskResult) => {
            console.log(`Pipeline Execution: Task ${taskResult.taskName} Ended`);
            return taskResult;
        });
    }
    // Run Pipeline !
    execute(siteDef) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.info(`PipelineExecutor (${this.executionKey}), Pending -> Running`);
            let ctx = {
                executionKey: this.executionKey,
                pipelineDef: this.pipelineDef,
                siteDef: siteDef,
                startTime: moment().toISOString(true),
                endTime: undefined,
                status: execution_status_1.ExecutionStatus.Running,
            };
            try {
                // Notify Start of Pipeline Execution
                this.notifyStartPipeline(ctx);
                // EXTRACT TASK - No input data for this task
                const taskExtractResult = yield this.runTask(this._tasks.extractTask, ctx);
                if (taskExtractResult.status != execution_status_1.ExecutionStatus.Completed) {
                    this.logger.error(`PipelineExecutor (${this.executionKey}), task ${taskExtractResult.taskName} not completed, stopping pipeline`);
                    this.notifyFinishedPipeline(ctx, execution_status_1.ExecutionStatus.Faulted);
                    return { context: ctx, results: [taskExtractResult] };
                }
                // TRANSFORM TASK
                const taskTransformResult = yield this.runTask(this._tasks.transformTask, ctx, taskExtractResult.result);
                if (taskTransformResult.status != execution_status_1.ExecutionStatus.Completed) {
                    this.logger.error(`PipelineExecutor (${this.executionKey}), task ${taskTransformResult.taskName} not completed, stopping pipeline`);
                    this.notifyFinishedPipeline(ctx, execution_status_1.ExecutionStatus.Faulted);
                    return { context: ctx, results: [taskExtractResult, taskTransformResult] };
                }
                // LOAD TASK
                const taskLoadResult = yield this.runTask(this._tasks.loadTask, ctx, taskTransformResult.result);
                if (taskLoadResult.status != execution_status_1.ExecutionStatus.Completed) {
                    this.logger.error(`PipelineExecutor (${this.executionKey}), task ${taskLoadResult.taskName} not completed, stopping pipeline`);
                    this.notifyFinishedPipeline(ctx, execution_status_1.ExecutionStatus.Faulted);
                    return {
                        context: ctx,
                        results: [taskExtractResult, taskTransformResult, taskLoadResult]
                    };
                }
                // Notify Success on Pipeline Execution
                this.notifyFinishedPipeline(ctx, taskLoadResult.status);
                return {
                    context: ctx,
                    results: [taskExtractResult, taskTransformResult, taskLoadResult]
                };
            }
            catch (err) {
                this.notifyFinishedPipeline(ctx, execution_status_1.ExecutionStatus.Faulted);
                return {
                    context: ctx,
                    results: []
                };
            }
        });
    }
    // Events on Starting and Completion
    notifyStartPipeline(context) {
        if (this._startEvent) {
            this._startEvent({ context });
        }
    }
    notifyFinishedPipeline(context, lastStatus) {
        if (this._finishEvent) {
            context.endTime = moment().toISOString(true);
            context.status = lastStatus;
            this._finishEvent({ context, finalStatus: lastStatus });
        }
    }
}
exports.PipelineExecution = PipelineExecution;
//# sourceMappingURL=pipeline-execution.js.map