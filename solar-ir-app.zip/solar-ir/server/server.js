"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Solar Irradiance Service Side App
 * This App provides REST API to manage sites and pipelines.
 * The user can create sites and linked those sites into pipeline. Then it can run the pipeline and query the data
 * provided by the pipeline.
 *
 * The App provide basic functionality and can be extended easily, most validations are missing due to the short
 * timing when writing this program.
 *
 * The workflow required to have a successfully execution of pipeline requires:
 * 1. Creating the Site (e.g. "Site1" with ID = 1)
 * 2. Creating the Pipeline  (e.g. "Pipeline1" with ID = 1)
 * 3. Creating Execution by link site to pipeline (e.g. Site1 <-> "Pipeline1"0 --> Getting Execution ID
 * 4. Query Execution Result after completion.
 *
 */
const express = require("express");
const http = require("http");
const bodyParser = require("body-parser");
const container_1 = require("./container");
const inversify_types_1 = require("./inversify.types");
const SITE_MGR_ROUTES = require("./routes/site_manager.routes");
const PIPELINE_MGR_ROUTES = require("./routes/pipeline_manager.routes");
const EXECUTION_MGR_ROUTES = require("./routes/execution_manager.routes");
class Server {
    constructor() {
        this.app = express();
        this.initCors = () => {
            const cors = require('cors');
            this.app.use(cors());
        };
        this.setRoutes = () => {
            this.app.use("/sites", Server.authenticateCall, SITE_MGR_ROUTES);
            this.app.use("/pipelines", Server.authenticateCall, PIPELINE_MGR_ROUTES);
            this.app.use("/executions", Server.authenticateCall, EXECUTION_MGR_ROUTES);
        };
        this.startServer = () => {
            http.createServer(this.app).
                listen(this.port).
                on('error', this.onError).
                on('listening', this.onServerListen);
        };
        this.setStaticFolders = () => {
            const path = require("path");
            this.app.use('/static', express.static(path.join(__dirname, '../client/dist')));
        };
        this.onServerListen = () => {
            console.log('App listening on port ' + this.port);
            this.initBackgroundWorkers();
        };
        this.onError = (err) => {
            switch (err.code) {
                case 'EACCES':
                    console.error('port requires elevated privileges');
                    process.exit(1);
                    break;
                case 'EADDRINUSE':
                    console.error('port is already in use');
                    process.exit(1);
                    break;
                default:
                    throw err;
            }
        };
        this.port = process.env.port ? parseInt(process.env.port) : 3000;
        this.app.use(bodyParser.json({ limit: '50mb' })); // support json encoded bodies
        this.app.use(bodyParser.urlencoded({ limit: '50mb', extended: true })); // support encoded bodies
        this.initCors();
        this.setRoutes();
        this.setStaticFolders();
        const home = `<p>Solar Irradiance App v1.0.0<br> Status: <p style="color:MediumSeaGreen;">Running ...</p></p>`;
        this.app.get('/', (req, res) => res.type('html').send(home));
        //Must be last
        this.set404Handler();
    }
    initBackgroundWorkers() {
        const workers = container_1.container.getAll(inversify_types_1.TYPES.BackgroundWorker);
        for (let worker of workers) {
            worker.init().catch(reason => this.logger.error(`Background worker '${worker.id}' error: ${reason}`));
        }
    }
    set404Handler() {
        this.app.use(function (req, res, next) {
            res.status(404).type('txt').send(`Page Not found: ${req.url}`);
        });
    }
    static authenticateCall(req, res, next) {
        next();
    }
}
__decorate([
    container_1.lazyInject(inversify_types_1.TYPES.Logger),
    __metadata("design:type", Object)
], Server.prototype, "logger", void 0);
exports.Server = Server;
//# sourceMappingURL=server.js.map