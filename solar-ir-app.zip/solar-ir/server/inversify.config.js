"use strict";
/**
 * Order of imports is IMPORTANT
 */
Object.defineProperty(exports, "__esModule", { value: true });
// Inversify related imports
const container_1 = require("./container");
const inversify_types_1 = require("./inversify.types");
const site_manager_1 = require("./managers/site_manager");
const logger_manager_1 = require("./managers/logger_manager");
const site_data_service_1 = require("./dal/site_data_service");
const pipeline_data_service_1 = require("./dal/pipeline_data.service");
const pipeline_manager_1 = require("./managers/pipeline_manager");
const execution_data_service_1 = require("./dal/execution_data.service");
const execution_manager_1 = require("./managers/execution_manager");
const task_factory_1 = require("./execution/task-factory");
const pipeline_executor_worker_1 = require("./execution/pipeline-executor-worker");
const execution_result_data_service_1 = require("./dal/execution-result-data.service");
const storage_utils_1 = require("./helpers/storage-utils");
const data_service_provider_1 = require("./dal/data-service-provider");
function init() {
    // Infrastructure
    container_1.container.bind(inversify_types_1.TYPES.Logger).toDynamicValue(ctx => {
        const filename = (process.env.logger || {}).file || "./logs/solar.log";
        const logLevel = (process.env.logger || { level: "info" }).level;
        return new logger_manager_1.LoggerManager({ file: { filename }, console: { level: logLevel } });
    }).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.LocalFileWriter).to(storage_utils_1.LocalFileWriter).inSingletonScope();
    // Factories & Services
    container_1.container.bind(inversify_types_1.TYPES.DBServiceProvider).to(data_service_provider_1.DataServiceProvider).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.TaskExecutionFactoryProvider).to(task_factory_1.TaskExecutionFactoryProvider).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.PipelineExecutorWorker).to(pipeline_executor_worker_1.PipelineExecutorWorker).inSingletonScope();
    // Data Services
    container_1.container.bind(inversify_types_1.TYPES.SiteDataService).to(site_data_service_1.SiteDataService).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.PipelineDataService).to(pipeline_data_service_1.PipelineDataService).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.ExecutionDataService).to(execution_data_service_1.ExecutionDataService).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.ExecutionResultDataService).to(execution_result_data_service_1.ExecutionResultDataService).inSingletonScope();
    // Managers
    container_1.container.bind(inversify_types_1.TYPES.SiteManager).to(site_manager_1.SiteManager).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.PipelineManager).to(pipeline_manager_1.PipelineManager).inSingletonScope();
    container_1.container.bind(inversify_types_1.TYPES.ExecutionManager).to(execution_manager_1.ExecutionManager).inSingletonScope();
    // Services
    container_1.container.bind(inversify_types_1.TYPES.BackgroundWorker).toService(inversify_types_1.TYPES.ExecutionManager);
}
exports.init = init;
//# sourceMappingURL=inversify.config.js.map