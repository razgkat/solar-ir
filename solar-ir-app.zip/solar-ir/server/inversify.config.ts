/**
 * Order of imports is IMPORTANT
 */

// Inversify related imports
import {container} from "./container";
import {TYPES} from "./inversify.types";
import {ISiteManager} from "./managers/site_manager.interface";
import {SiteManager} from "./managers/site_manager";
import {ILogger, LoggerManager, LogLevel} from "./managers/logger_manager";
import {ISiteDataService} from "./dal/site_data.service.interface";
import {SiteDataService} from "./dal/site_data_service";
import {IPipelineDataService} from "./dal/pipeline_data.service.interface";
import {PipelineDataService} from "./dal/pipeline_data.service";
import {IPipelineManager} from "./managers/pipeline_manager.interface";
import {PipelineManager} from "./managers/pipeline_manager";
import {IExecutionDataService} from "./dal/execution_data.service.interface";
import {ExecutionDataService} from "./dal/execution_data.service";
import {IExecutionManager} from "./managers/execution_manager.interface";
import {ExecutionManager} from "./managers/execution_manager";
import {ITaskExecutionFactoryProvider, TaskExecutionFactoryProvider} from "./execution/task-factory";
import {IPipelineExecutorWorker, PipelineExecutorWorker} from "./execution/pipeline-executor-worker";
import {IBackgroundWorker} from "./helpers/background-worker";
import {ExecutionResultDataService} from "./dal/execution-result-data.service";
import {IExecutionResultDataService} from "./dal/execution-result-data.service.interface";
import {ILocalFileWriter, LocalFileWriter} from "./helpers/storage-utils";
import {DataServiceProvider, IDBServiceProvider} from "./dal/data-service-provider";

export function init() {

    // Infrastructure
    container.bind<ILogger>(TYPES.Logger).toDynamicValue(ctx => {
        const filename = (process.env.logger || {} as any).file || "./logs/solar.log";
        const logLevel: LogLevel = (process.env.logger || { level: "info" } as any).level as LogLevel;
        return new LoggerManager({file: {filename}, console: {level: logLevel}});
    }).inSingletonScope();

    container.bind<ILocalFileWriter>(TYPES.LocalFileWriter).to(LocalFileWriter).inSingletonScope();

    // Factories & Services
    container.bind<IDBServiceProvider>(TYPES.DBServiceProvider).to(DataServiceProvider).inSingletonScope();
    container.bind<ITaskExecutionFactoryProvider>(TYPES.TaskExecutionFactoryProvider).to(TaskExecutionFactoryProvider).inSingletonScope();
    container.bind<IPipelineExecutorWorker>(TYPES.PipelineExecutorWorker).to(PipelineExecutorWorker).inSingletonScope();

    // Data Services
    container.bind<ISiteDataService>(TYPES.SiteDataService).to(SiteDataService).inSingletonScope();
    container.bind<IPipelineDataService>(TYPES.PipelineDataService).to(PipelineDataService).inSingletonScope();
    container.bind<IExecutionDataService>(TYPES.ExecutionDataService).to(ExecutionDataService).inSingletonScope();
    container.bind<IExecutionResultDataService>(TYPES.ExecutionResultDataService).to(ExecutionResultDataService).inSingletonScope();

    // Managers
    container.bind<ISiteManager>(TYPES.SiteManager).to(SiteManager).inSingletonScope();
    container.bind<IPipelineManager>(TYPES.PipelineManager).to(PipelineManager).inSingletonScope();
    container.bind<IExecutionManager>(TYPES.ExecutionManager).to(ExecutionManager).inSingletonScope();

    // Services
    container.bind<IBackgroundWorker>(TYPES.BackgroundWorker).toService(TYPES.ExecutionManager);

}

