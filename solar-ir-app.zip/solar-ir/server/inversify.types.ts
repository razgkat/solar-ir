import {TaskExecutionFactoryProvider} from "./execution/task-factory";
import {PipelineExecutorWorker} from "./execution/pipeline-executor-worker";
import {DataServiceProvider} from "./dal/data-service-provider";

export const TYPES = {
    Logger: Symbol.for("Logger"),

    DBServiceProvider: Symbol.for("DBServiceProvider"),
    TaskExecutionFactoryProvider: Symbol.for("TaskExecutionFactoryProvider"),
    PipelineExecutorWorker: Symbol.for("PipelineExecutorWorker"),
    BackgroundWorker: Symbol.for("IBackgroundWorker"),
    LocalFileWriter: Symbol.for("LocalFileWriter"),

    SiteDataService: Symbol.for("SiteDataService"),
    PipelineDataService: Symbol.for("PipelineDataService"),
    ExecutionDataService: Symbol.for("ExecutionDataService"),
    ExecutionResultDataService: Symbol.for("ExecutionResultDataService"),

    SiteManager: Symbol.for("SiteManager"),
    PipelineManager: Symbol.for("PipelineManager"),
    ExecutionManager: Symbol.for("ExecutionManager")
};

