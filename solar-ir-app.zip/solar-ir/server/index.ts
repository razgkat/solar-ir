import * as dotenv from "dotenv";
import * as dotenvExpand from "dotenv-expand";
import { Server} from "./server";

dotenvExpand(dotenv.config({path: __dirname + "/.env"}));
process.env.__basedir = __dirname;

try {
    require("./inversify.config").init();
    const server = new Server();
    server.startServer();
} catch (e) {
    console.error(e);
}



