import {Router} from "express";
import {container} from "../container";
import {TYPES} from "../inversify.types";
import {RequestStatus} from "../../common/enums/request-status";
import {IPipelineManager} from "../managers/pipeline_manager.interface";
import {AddPipelineRequest, GetPipelineResponse} from "../../common/models/pipeline-request-response";

/*
    REST API for pipeline functionality
*/

const router: Router = Router();

function getPipelineManager(): IPipelineManager {
    return container.get<IPipelineManager>(TYPES.PipelineManager);
}

router.post("/add",async (req, res, next) => {
    try {
        const addPipelineRequest: AddPipelineRequest = req.body;
        const result = await getPipelineManager().addPipeline(addPipelineRequest);
        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/:id",async (req, res, next) => {
    try {
        const id: number = Number(req.params.id);
        const result:GetPipelineResponse = await getPipelineManager().getPipeline(id);
        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/",async (req, res, next) => {
    try {
        res.send(await getPipelineManager().getPipelines());
    } catch (err) {
        return next(err)
    }
});


module.exports = router;