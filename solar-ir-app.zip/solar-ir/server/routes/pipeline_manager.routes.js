"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const container_1 = require("../container");
const inversify_types_1 = require("../inversify.types");
const request_status_1 = require("../../common/enums/request-status");
/*
    REST API for pipeline functionality
*/
const router = express_1.Router();
function getPipelineManager() {
    return container_1.container.get(inversify_types_1.TYPES.PipelineManager);
}
router.post("/add", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const addPipelineRequest = req.body;
        const result = yield getPipelineManager().addPipeline(addPipelineRequest);
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/:id", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const id = Number(req.params.id);
        const result = yield getPipelineManager().getPipeline(id);
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        res.send(yield getPipelineManager().getPipelines());
    }
    catch (err) {
        return next(err);
    }
}));
module.exports = router;
//# sourceMappingURL=pipeline_manager.routes.js.map