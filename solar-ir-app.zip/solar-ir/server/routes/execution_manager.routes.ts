import {Router} from "express";
import {container} from "../container";
import {TYPES} from "../inversify.types";
import {RequestStatus} from "../../common/enums/request-status";
import {IExecutionManager} from "../managers/execution_manager.interface";
import {GetExecutionResultResponse, GetExecutionsResponse} from "../../common/models/execution-request-response";
import {ExecutionStatus} from "../../common/enums/execution-status";
import {ObjectHelper} from "../helpers/object-utils";

/*
    REST API for related execution functionality
*/

const router: Router = Router();

function getExecutionManager(): IExecutionManager {
    return container.get<IExecutionManager>(TYPES.ExecutionManager);
}

router.get("/",async (req, res, next) => {
    try {

        const siteId: number = req.query.siteId ? Number(req.query.siteId): undefined
        const status: ExecutionStatus = req.query.status
        const key: string = req.query.key;

        const result:GetExecutionsResponse =
            await getExecutionManager().getExecutions(ObjectHelper.removeNullOrUndefined({siteId, key, status}));

        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/results",async (req, res, next) => {
    try {
        const key = req.params.key;

        const result:GetExecutionResultResponse = await getExecutionManager().getExecutionResult();

        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/results/:key",async (req, res, next) => {
    try {
        const executionKey = req.params.key;

        const result:GetExecutionResultResponse =
            await getExecutionManager().getExecutionResult(ObjectHelper.removeNullOrUndefined({executionKey}));

        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/run/:key",async (req, res, next) => {
    try {

        const executionKey = req.params.key;
        const result = await getExecutionManager().runExecutionBusy(executionKey);
        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

module.exports = router;