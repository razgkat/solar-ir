import {Router} from "express";
import {ISiteManager} from "../managers/site_manager.interface";
import {container} from "../container";
import {TYPES} from "../inversify.types";
import {AddSiteRequest, ExecuteSiteRequest, GetSiteResponse} from "../../common/models/site-request-response";
import {RequestStatus} from "../../common/enums/request-status";

/*
    REST API for site functionality
*/

const router: Router = Router();

function getSiteManager(): ISiteManager {
    return container.get<ISiteManager>(TYPES.SiteManager);
}

router.post("/add",async (req, res, next) => {
    try {
        const addSiteRequest: AddSiteRequest = req.body;
        const result = await getSiteManager().addSite(addSiteRequest);
        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.put("/execute",async (req, res, next) => {
    try {
        const executeRequest: ExecuteSiteRequest = req.body;
        const result = await getSiteManager().executeSite(executeRequest);
        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/:idOrName",async (req, res, next) => {
    try {
        const idOrName: string | number = req.params.idOrName;
        const result:GetSiteResponse = await getSiteManager().getSite(idOrName);
        res.status(RequestStatus.toHttpStatus(result.status))
        res.send(result);
    } catch (err) {
        return next(err)
    }
});

router.get("/",async (req, res, next) => {
    try {
        res.send(await getSiteManager().getSites());
    } catch (err) {
        return next(err)
    }
});


module.exports = router;