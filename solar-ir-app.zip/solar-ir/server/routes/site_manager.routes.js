"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const container_1 = require("../container");
const inversify_types_1 = require("../inversify.types");
const request_status_1 = require("../../common/enums/request-status");
/*
    REST API for site functionality
*/
const router = express_1.Router();
function getSiteManager() {
    return container_1.container.get(inversify_types_1.TYPES.SiteManager);
}
router.post("/add", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const addSiteRequest = req.body;
        const result = yield getSiteManager().addSite(addSiteRequest);
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.put("/execute", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const executeRequest = req.body;
        const result = yield getSiteManager().executeSite(executeRequest);
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/:idOrName", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const idOrName = req.params.idOrName;
        const result = yield getSiteManager().getSite(idOrName);
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        res.send(yield getSiteManager().getSites());
    }
    catch (err) {
        return next(err);
    }
}));
module.exports = router;
//# sourceMappingURL=site_manager.routes.js.map