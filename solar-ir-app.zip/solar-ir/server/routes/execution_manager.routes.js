"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const container_1 = require("../container");
const inversify_types_1 = require("../inversify.types");
const request_status_1 = require("../../common/enums/request-status");
const object_utils_1 = require("../helpers/object-utils");
/*
    REST API for related execution functionality
*/
const router = express_1.Router();
function getExecutionManager() {
    return container_1.container.get(inversify_types_1.TYPES.ExecutionManager);
}
router.get("/", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const siteId = req.query.siteId ? Number(req.query.siteId) : undefined;
        const status = req.query.status;
        const key = req.query.key;
        const result = yield getExecutionManager().getExecutions(object_utils_1.ObjectHelper.removeNullOrUndefined({ siteId, key, status }));
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/results", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const key = req.params.key;
        const result = yield getExecutionManager().getExecutionResult();
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/results/:key", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const executionKey = req.params.key;
        const result = yield getExecutionManager().getExecutionResult(object_utils_1.ObjectHelper.removeNullOrUndefined({ executionKey }));
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
router.get("/run/:key", (req, res, next) => __awaiter(this, void 0, void 0, function* () {
    try {
        const executionKey = req.params.key;
        const result = yield getExecutionManager().runExecutionBusy(executionKey);
        res.status(request_status_1.RequestStatus.toHttpStatus(result.status));
        res.send(result);
    }
    catch (err) {
        return next(err);
    }
}));
module.exports = router;
//# sourceMappingURL=execution_manager.routes.js.map