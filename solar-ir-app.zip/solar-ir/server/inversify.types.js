"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TYPES = {
    Logger: Symbol.for("Logger"),
    DBServiceProvider: Symbol.for("DBServiceProvider"),
    TaskExecutionFactoryProvider: Symbol.for("TaskExecutionFactoryProvider"),
    PipelineExecutorWorker: Symbol.for("PipelineExecutorWorker"),
    BackgroundWorker: Symbol.for("IBackgroundWorker"),
    LocalFileWriter: Symbol.for("LocalFileWriter"),
    SiteDataService: Symbol.for("SiteDataService"),
    PipelineDataService: Symbol.for("PipelineDataService"),
    ExecutionDataService: Symbol.for("ExecutionDataService"),
    ExecutionResultDataService: Symbol.for("ExecutionResultDataService"),
    SiteManager: Symbol.for("SiteManager"),
    PipelineManager: Symbol.for("PipelineManager"),
    ExecutionManager: Symbol.for("ExecutionManager")
};
//# sourceMappingURL=inversify.types.js.map