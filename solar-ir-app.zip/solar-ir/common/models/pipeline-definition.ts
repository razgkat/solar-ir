import {TaskExtractDefinition, TaskLoadDefinition, TaskTransformDefinition} from "./tasks/task-definition";

export interface PipelineDefinition
{
    id: number;
    name: string;

    tasks: {
        extract: TaskExtractDefinition,
        transform: TaskTransformDefinition,
        load: TaskLoadDefinition
    }
}