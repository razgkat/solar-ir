import {TaskLoadDefinition} from "./task-definition";
import {FileFormat} from "../../enums/file-format";

export interface NrelSolarFileTaskLoadDefinition extends TaskLoadDefinition
{
    // Minimal Example of Task Writing to a Local File

    input: {
        outputFile: string;
        format: FileFormat;
    }
}