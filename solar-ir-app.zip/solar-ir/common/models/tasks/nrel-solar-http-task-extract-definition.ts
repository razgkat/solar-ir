import {TaskExtractDefinition} from "./task-definition";

export enum NRELSolarDataInputFormats
{
    JSON = "json",
    XML = "xml"
}

export interface NrelSolarHttpTaskExtractDefinition extends TaskExtractDefinition
{
    input: {
        uri: string;
        port: number;
        version: number;
        format: NRELSolarDataInputFormats;
        uriParameters: {
            api_key: string
        }
    }
}