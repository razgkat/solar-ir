import {TaskLoadDefinition} from "./task-definition";
import {FileFormat} from "../../enums/file-format";

export interface NrelSolarDbTaskLoadDefinition extends TaskLoadDefinition
{
    // Minimal Example of Task Writing to a DB

    input: {
        dbService: string;
        serviceArgs: any;
    }
}