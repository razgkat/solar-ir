"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var NRELSolarDataInputFormats;
(function (NRELSolarDataInputFormats) {
    NRELSolarDataInputFormats["JSON"] = "json";
    NRELSolarDataInputFormats["XML"] = "xml";
})(NRELSolarDataInputFormats = exports.NRELSolarDataInputFormats || (exports.NRELSolarDataInputFormats = {}));
//# sourceMappingURL=nrel-solar-http-task-extract-definition.js.map