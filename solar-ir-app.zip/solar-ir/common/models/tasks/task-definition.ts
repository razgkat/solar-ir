export interface TaskDefinition
{
    name: string;
}

export interface TaskExtractDefinition extends TaskDefinition
{

}

export interface TaskTransformDefinition extends TaskDefinition
{

}

export interface TaskLoadDefinition extends TaskDefinition
{

}

