import {TaskTransformDefinition} from "./task-definition";

export interface NrelSolarFlatTaskTransformDefinition extends TaskTransformDefinition
{
    input: { }
}