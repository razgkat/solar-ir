import {ExecutionStatus} from "../../enums/execution-status";

export interface TaskExecutionResult {

    taskUuid: string;
    taskName: string;
    result?: any[];
    status: ExecutionStatus;
}