import {SolarPeriod} from "../enums/solar-period";
import {ExecutionDataResult} from "./execution-data-result";

export enum SolarMetricType
{
    AVG_DNI = "avg_dni",
    AVG_GHI = "avg_ghi",
    AVG_LAT_TILT = "avg_lat_tilt"
}

/*
    Presents a flatted record for NREL Solar Data
 */
export interface SolarMetric extends ExecutionDataResult {
    siteName: string;
    siteId: number;
    pipelineName: string;
    pipelineId: number;
    source: string;
    version: string,
    type: SolarMetricType;
    period: SolarPeriod;
    value: number;
}
