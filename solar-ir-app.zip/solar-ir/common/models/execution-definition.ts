import {ExecutionStatus} from "../enums/execution-status";

export interface ExecutionDefinition {
    key: string;
    siteId: number;
    pipelineId: number;
    status: ExecutionStatus;
}