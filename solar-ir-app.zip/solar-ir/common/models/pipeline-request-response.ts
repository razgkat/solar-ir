import {RequestStatus} from "../enums/request-status";
import {PipelineDefinition} from "./pipeline-definition";
import {SiteDefinition} from "./site-definition";

export interface AddPipelineRequest {
    pipeline: PipelineDefinition;
}

export interface AddPipelineResponse {
    id?: number;
    status: RequestStatus;
}

export interface GetPipelineResponse {
    pipeline?: PipelineDefinition;
    status: RequestStatus;
    reason?: string;
}

export interface GetPipelinesResponse {
    pipelines: PipelineDefinition[];
    status: RequestStatus;
}