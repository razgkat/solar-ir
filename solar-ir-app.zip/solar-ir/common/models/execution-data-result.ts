export interface ExecutionDataResult
{
    executionKey: string;
}