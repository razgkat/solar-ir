"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SolarMetricType;
(function (SolarMetricType) {
    SolarMetricType["AVG_DNI"] = "avg_dni";
    SolarMetricType["AVG_GHI"] = "avg_ghi";
    SolarMetricType["AVG_LAT_TILT"] = "avg_lat_tilt";
})(SolarMetricType = exports.SolarMetricType || (exports.SolarMetricType = {}));
//# sourceMappingURL=solar-metric.js.map