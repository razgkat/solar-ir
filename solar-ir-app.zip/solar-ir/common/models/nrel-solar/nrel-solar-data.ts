import {SiteLocation} from "../site-definition";
import {SolarPeriod} from "../../enums/solar-period";

export interface NrelSolarDataMetric {
    annual: number,
    monthly: {
        jan: number,
        feb: number,
        mar: number,
        apr: number,
        may: number,
        jun: number,
        jul: number,
        aug: number,
        sep: number,
        oct: number,
        nov: number,
        dec: number
    }
}

export interface NrelSolarData {
    version: string,
    warnings: string[],
    errors: string[],
    metadata: {
        sources: string[]
    },
    inputs: SiteLocation,
    outputs: {
        avg_dni: NrelSolarDataMetric,
        avg_ghi: NrelSolarDataMetric,
        avg_lat_tilt: NrelSolarDataMetric
    }
}

export namespace NrelDataConvertors {

    export type NrelPeriodVals = "jan" | "feb" | "mar" | "apr"| "may" | "jun" | "jul" | "aug" | "sep" | "oct" | "nov" | "dec" | "annual"

    const fromMonthToValueMap: Map<NrelPeriodVals, SolarPeriod> = new Map<NrelPeriodVals, SolarPeriod>([
        ["jan", SolarPeriod.January],
        ["feb", SolarPeriod.February],
        ["mar", SolarPeriod.March],
        ["apr", SolarPeriod.April],
        ["may", SolarPeriod.May],
        ["jun", SolarPeriod.June],
        ["jul", SolarPeriod.July],
        ["aug", SolarPeriod.August],
        ["sep", SolarPeriod.September],
        ["oct", SolarPeriod.October],
        ["nov", SolarPeriod.November],
        ["dec", SolarPeriod.December],
        ["annual", SolarPeriod.Annual]

    ]);

    export function fromPeriodStringToMappedValue(period: NrelPeriodVals): SolarPeriod {
        return fromMonthToValueMap.get(period);
    }
}