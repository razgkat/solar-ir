"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const solar_period_1 = require("../../enums/solar-period");
var NrelDataConvertors;
(function (NrelDataConvertors) {
    const fromMonthToValueMap = new Map([
        ["jan", solar_period_1.SolarPeriod.January],
        ["feb", solar_period_1.SolarPeriod.February],
        ["mar", solar_period_1.SolarPeriod.March],
        ["apr", solar_period_1.SolarPeriod.April],
        ["may", solar_period_1.SolarPeriod.May],
        ["jun", solar_period_1.SolarPeriod.June],
        ["jul", solar_period_1.SolarPeriod.July],
        ["aug", solar_period_1.SolarPeriod.August],
        ["sep", solar_period_1.SolarPeriod.September],
        ["oct", solar_period_1.SolarPeriod.October],
        ["nov", solar_period_1.SolarPeriod.November],
        ["dec", solar_period_1.SolarPeriod.December],
        ["annual", solar_period_1.SolarPeriod.Annual]
    ]);
    function fromPeriodStringToMappedValue(period) {
        return fromMonthToValueMap.get(period);
    }
    NrelDataConvertors.fromPeriodStringToMappedValue = fromPeriodStringToMappedValue;
})(NrelDataConvertors = exports.NrelDataConvertors || (exports.NrelDataConvertors = {}));
//# sourceMappingURL=nrel-solar-data.js.map