export interface SiteLocation {
    lat: number;
    lon: number;
}

export interface SiteDefinition {
    name: string;
    id: number;
    location: SiteLocation

    // Linked Pipeline
    pipeline: {
        id: number;
    };
}