import {RequestStatus} from "../enums/request-status";
import {ExecutionDefinition} from "./execution-definition";
import {SolarMetric} from "./solar-metric";
import {ExecutionDataResult} from "./execution-data-result";

export interface GetExecutionsResponse
{
    executions: ExecutionDefinition[];
    status: RequestStatus;
}

export interface GetExecutionResultResponse {
    status: RequestStatus;
    message?: string;
    results?: ExecutionDataResult[];
}