import {SiteDefinition} from "./site-definition";
import {RequestStatus} from "../enums/request-status";
import {ExecutionDefinition} from "./execution-definition";

export interface  AddSiteRequest {
    site: SiteDefinition;
}

export interface AddSiteResponse {
    id?: number;
    status: RequestStatus;
    reason?: string;
}

export interface GetSiteResponse {
    site?: SiteDefinition;
    status: RequestStatus;
    reason?: string;
}

export interface GetSitesResponse {
    sites: SiteDefinition[];
    status: RequestStatus;
}

export interface ExecuteSiteRequest {
    siteId: number;
    pipelineId?: number;
}

export interface ExecuteSiteResponse {
    executionInfo?: ExecutionDefinition;
    status: RequestStatus;
    message?: string;
}

