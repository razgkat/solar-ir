export enum TaskType {
    Extract,
    Transform,
    Load
}