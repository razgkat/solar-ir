"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Status;
(function (Status) {
    Status["Success"] = "Success";
    Status["Failed"] = "Failed";
    Status["NotFound"] = "NotFound";
})(Status = exports.Status || (exports.Status = {}));
//# sourceMappingURL=status.js.map