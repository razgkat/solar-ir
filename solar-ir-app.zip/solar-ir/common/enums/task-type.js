"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TaskType;
(function (TaskType) {
    TaskType[TaskType["Extract"] = 0] = "Extract";
    TaskType[TaskType["Transform"] = 1] = "Transform";
    TaskType[TaskType["Load"] = 2] = "Load";
})(TaskType = exports.TaskType || (exports.TaskType = {}));
//# sourceMappingURL=task-type.js.map