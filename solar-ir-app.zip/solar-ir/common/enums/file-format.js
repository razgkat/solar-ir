"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FileFormat;
(function (FileFormat) {
    FileFormat["CSV"] = "csv";
    FileFormat["JSON"] = "json";
})(FileFormat = exports.FileFormat || (exports.FileFormat = {}));
//# sourceMappingURL=file-format.js.map