"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RequestStatus;
(function (RequestStatus) {
    RequestStatus["Success"] = "Success";
    RequestStatus["Failed"] = "Failed";
    RequestStatus["NotFound"] = "NotFound";
})(RequestStatus = exports.RequestStatus || (exports.RequestStatus = {}));
(function (RequestStatus) {
    const map = new Map([
        [RequestStatus.Success, 200],
        [RequestStatus.Failed, 400],
        [RequestStatus.NotFound, 404],
    ]);
    function toHttpStatus(reqStatus) {
        return map.get(reqStatus);
    }
    RequestStatus.toHttpStatus = toHttpStatus;
})(RequestStatus = exports.RequestStatus || (exports.RequestStatus = {}));
//# sourceMappingURL=request-status.js.map