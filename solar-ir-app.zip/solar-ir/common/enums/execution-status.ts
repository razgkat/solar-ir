export enum ExecutionStatus {
    Pending = "PENDING",
    Running = "RUNNING",
    Faulted = "FAULTED",
    Completed = "COMPLETED",
    Cancelled = "CANCELLED"
}

export namespace ExecutionStatus
{
    const finalStatuses = [
        ExecutionStatus.Faulted,
        ExecutionStatus.Completed,
        ExecutionStatus.Cancelled
    ];

    export function isFinal(status: ExecutionStatus) {
        return finalStatuses.indexOf(status) > -1;
    }
}