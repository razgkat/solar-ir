export enum DbServiceType
{
    NeDB = "NeDB"
}
