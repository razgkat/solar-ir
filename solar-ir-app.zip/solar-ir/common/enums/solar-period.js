"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SolarPeriod;
(function (SolarPeriod) {
    SolarPeriod["January"] = "January";
    SolarPeriod["February"] = "February";
    SolarPeriod["March"] = "March";
    SolarPeriod["April"] = "April";
    SolarPeriod["May"] = "May";
    SolarPeriod["June"] = "June";
    SolarPeriod["July"] = "July";
    SolarPeriod["August"] = "August";
    SolarPeriod["September"] = "September";
    SolarPeriod["October"] = "October";
    SolarPeriod["November"] = "November";
    SolarPeriod["December"] = "December";
    SolarPeriod["Annual"] = "Annual";
})(SolarPeriod = exports.SolarPeriod || (exports.SolarPeriod = {}));
//# sourceMappingURL=solar-period.js.map