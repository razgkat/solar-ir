"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DbServiceType;
(function (DbServiceType) {
    DbServiceType["NeDB"] = "NeDB";
})(DbServiceType = exports.DbServiceType || (exports.DbServiceType = {}));
//# sourceMappingURL=db-service-type.js.map