export enum FileFormat
{
    CSV = "csv",
    JSON = "json"
}