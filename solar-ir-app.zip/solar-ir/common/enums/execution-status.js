"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ExecutionStatus;
(function (ExecutionStatus) {
    ExecutionStatus["Pending"] = "PENDING";
    ExecutionStatus["Running"] = "RUNNING";
    ExecutionStatus["Faulted"] = "FAULTED";
    ExecutionStatus["Completed"] = "COMPLETED";
    ExecutionStatus["Cancelled"] = "CANCELLED";
})(ExecutionStatus = exports.ExecutionStatus || (exports.ExecutionStatus = {}));
(function (ExecutionStatus) {
    const finalStatuses = [
        ExecutionStatus.Faulted,
        ExecutionStatus.Completed,
        ExecutionStatus.Cancelled
    ];
    function isFinal(status) {
        return finalStatuses.indexOf(status) > -1;
    }
    ExecutionStatus.isFinal = isFinal;
})(ExecutionStatus = exports.ExecutionStatus || (exports.ExecutionStatus = {}));
//# sourceMappingURL=execution-status.js.map