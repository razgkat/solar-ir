export enum RequestStatus {
    Success =  "Success",
    Failed = "Failed",
    NotFound = "NotFound"
}

export namespace RequestStatus {

    const map: Map<RequestStatus, number> = new Map<RequestStatus, number>([
        [RequestStatus.Success, 200],
        [RequestStatus.Failed, 400],
        [RequestStatus.NotFound, 404],
    ]);

    export function toHttpStatus(reqStatus: RequestStatus ): number {
        return map.get(reqStatus);
    }

}